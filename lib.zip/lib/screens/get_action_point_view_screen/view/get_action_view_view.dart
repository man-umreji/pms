import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:file_picker/file_picker.dart';
import '../../main_screen/view/main_screen_view.dart';
import '../model/get_action_point_model.dart';
import '../model/get_all_status_model.dart';
import '../model/update_action_point_model.dart';
import '../view_model/get_action_view_view_model.dart';

class ActionPointViewScreen extends StatefulWidget {
  final int meetingId;

  const ActionPointViewScreen({
    super.key,
    required this.meetingId,
  });

  @override
  State<ActionPointViewScreen> createState() => _ActionPointViewScreenState();
}

class _ActionPointViewScreenState extends State<ActionPointViewScreen> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() {
      Provider.of<GetActionPointViewModel>(context, listen: false)
          .fetchActionPointView(widget.meetingId);
    });
  }

  Future<void> _showDeleteConfirmation(
      BuildContext context, String actionPointId, String description) async {
    return showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24.r)),
          child: Container(
            padding: EdgeInsets.all(20.w),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: EdgeInsets.all(16.w),
                  decoration: BoxDecoration(
                    color: Colors.red.shade50,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(Icons.delete_outline, size: 48.sp, color: Colors.red.shade400),
                ),
                SizedBox(height: 16.h),
                Text(
                  "Delete Action Point",
                  style: TextStyle(
                    fontSize: 20.sp,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey.shade800,
                  ),
                ),
                SizedBox(height: 8.h),
                Text(
                  "Are you sure you want to delete?",
                  style: TextStyle(fontSize: 14.sp, color: Colors.grey.shade600),
                ),
                SizedBox(height: 12.h),
                Container(
                  padding: EdgeInsets.all(12.w),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade50,
                    borderRadius: BorderRadius.circular(12.r),
                    border: Border.all(color: Colors.grey.shade200),
                  ),
                  child: Text(
                    description,
                    style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.w500),
                    textAlign: TextAlign.center,
                  ),
                ),
                SizedBox(height: 20.h),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.pop(context),
                        style: OutlinedButton.styleFrom(
                          padding: EdgeInsets.symmetric(vertical: 12.h),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12.r),
                          ),
                        ),
                        child: Text("Cancel"),
                      ),
                    ),
                    SizedBox(width: 12.w),
                    Expanded(
                      child: Consumer<GetActionPointViewModel>(
                        builder: (context, vm, _) {
                          return ElevatedButton(
                            onPressed: vm.isUpdating
                                ? null
                                : () async {
                              Navigator.pop(context);

                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text("Delete functionality coming soon"),
                                  backgroundColor: Colors.orange,
                                ),
                              );
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.red,
                              padding: EdgeInsets.symmetric(vertical: 12.h),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12.r),
                              ),
                            ),
                            child: vm.isUpdating
                                ? SizedBox(
                              height: 20.h,
                              width: 20.w,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                                : Text("Delete"),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }





  Widget _buildAssigneeField({
    required TextEditingController controller,
    required GetActionPointViewModel vm,
    required Function(String id, String name) onAssigneeSelected,
  }) {
    final assignees = vm.response?.data?.projects ?? [];

    return GestureDetector(
      onTap: () {
        if (assignees.isEmpty) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('No assignees available')),
          );
          return;
        }

        showModalBottomSheet(
          context: context,
          builder: (context) {
            return Container(
              height: 400,
              padding: EdgeInsets.all(16.w),
              child: Column(
                children: [
                  Text(
                    'Select Assignee',
                    style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 16.h),
                  Expanded(
                    child: ListView.builder(
                      itemCount: assignees.length,
                      itemBuilder: (context, index) {
                        final project = assignees[index];
                        return ListTile(
                          leading: const Icon(Icons.person),
                          title: Text(project.name ?? 'Unnamed'),
                          subtitle: Text('Project ID: ${project.projectCode ?? 'N/A'}'),
                          onTap: () {
                            onAssigneeSelected(project.id ?? '', project.name ?? '');
                            Navigator.pop(context);
                          },
                        );
                      },
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
      child: AbsorbPointer(
        child: TextFormField(
          controller: controller,
          decoration: InputDecoration(
            labelText: "Assigned To *",
            hintText: "Tap to select assignee",
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.r),
            ),
            prefixIcon: Icon(Icons.person, color: Colors.blue.shade600),
            suffixIcon: Icon(Icons.arrow_drop_down, color: Colors.grey.shade400),
          ),
          validator: (value) => value?.isEmpty == true ? "Assignee is required" : null,
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    int maxLines = 1,
    String? Function(String?)? validator,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(12.r),
      ),
      child: TextFormField(
        controller: controller,
        maxLines: maxLines,
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12.r),
            borderSide: BorderSide(color: Colors.grey.shade300),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12.r),
            borderSide: BorderSide(color: Colors.grey.shade300),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12.r),
            borderSide: BorderSide(color: Colors.blue.shade600, width: 2),
          ),
          prefixIcon: Icon(icon, color: Colors.blue.shade600),
          filled: true,
          fillColor: Colors.white,
        ),
        validator: validator,
      ),
    );
  }

  Widget _buildRemarkField({required TextEditingController controller}) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.orange.shade50, Colors.orange.shade100],
        ),
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(color: Colors.orange.shade200),
      ),
      child: Padding(
        padding: EdgeInsets.all(12.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.warning_amber_rounded, color: Colors.orange.shade700, size: 20.sp),
                SizedBox(width: 8.w),
                Text(
                  "Mandatory Field",
                  style: TextStyle(
                    color: Colors.orange.shade700,
                    fontWeight: FontWeight.w600,
                    fontSize: 12.sp,
                  ),
                ),
              ],
            ),
            SizedBox(height: 8.h),
            TextFormField(
              controller: controller,
              decoration: InputDecoration(
                labelText: "Remark",
                hintText: "Please provide your remarks",
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10.r),
                  borderSide: BorderSide.none,
                ),
                prefixIcon: Icon(Icons.comment, color: Colors.orange.shade600),
                filled: true,
                fillColor: Colors.white,
              ),
              maxLines: 2,
              validator: (value) => value?.trim().isEmpty == true ? "Remark is mandatory" : null,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusDropdown({
    required String value,
    required List<StatusList>? statusList,
    required Function(String?) onChanged,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(12.r),
      ),
      child: DropdownButtonFormField<String>(
        value: value,
        decoration: InputDecoration(
          labelText: "Status",
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12.r),
            borderSide: BorderSide(color: Colors.grey.shade300),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12.r),
            borderSide: BorderSide(color: Colors.grey.shade300),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12.r),
            borderSide: BorderSide(color: Colors.blue.shade600, width: 2),
          ),
          prefixIcon: Icon(Icons.flag, color: Colors.blue.shade600),
          filled: true,
          fillColor: Colors.white,
        ),
        items: statusList?.map((status) {
          return DropdownMenuItem<String>(
            value: status.value,
            child: Row(
              children: [
                Container(
                  width: 8.w,
                  height: 8.h,
                  decoration: BoxDecoration(
                    color: _getStatusColor(status.value),
                    shape: BoxShape.circle,
                  ),
                ),
                SizedBox(width: 8.w),
                Text(status.label ?? status.value ?? ''),
              ],
            ),
          );
        }).toList(),
        onChanged: onChanged,
      ),
    );
  }

  Widget _buildDateField({
    required TextEditingController controller,
    required BuildContext context,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(12.r),
      ),
      child: TextFormField(
        controller: controller,
        decoration: InputDecoration(
          labelText: "Target Date *",
          hintText: "Select target date",
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12.r),
            borderSide: BorderSide(color: Colors.grey.shade300),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12.r),
            borderSide: BorderSide(color: Colors.grey.shade300),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12.r),
            borderSide: BorderSide(color: Colors.blue.shade600, width: 2),
          ),
          prefixIcon: Icon(Icons.calendar_today, color: Colors.blue.shade600),
          suffixIcon: Icon(Icons.arrow_drop_down, color: Colors.grey.shade400),
          filled: true,
          fillColor: Colors.white,
        ),
        readOnly: true,
        onTap: () async {
          DateTime? pickedDate = await showDatePicker(
            context: context,
            initialDate: DateTime.now(),
            firstDate: DateTime.now(),
            lastDate: DateTime.now().add(const Duration(days: 365)),
            builder: (context, child) {
              return Theme(
                data: Theme.of(context).copyWith(
                  colorScheme: ColorScheme.light(
                    primary: Colors.blue.shade600,
                    onPrimary: Colors.white,
                    onSurface: Colors.black,
                  ),
                ),
                child: child!,
              );
            },
          );
          if (pickedDate != null) {
            controller.text = pickedDate.toLocal().toString().split(' ')[0];
          }
        },
        validator: (value) => value?.isEmpty == true ? "Target date is required" : null,
      ),
    );
  }

  Widget _buildAttachmentsSection(GetActionPointViewModel vm) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(12.r),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.all(12.w),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Attachments',
                  style: TextStyle(
                    fontSize: 14.sp,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                TextButton.icon(
                  onPressed: (){},
                  // onPressed: () async {
                  //   FilePickerResult? result = await FilePicker.platform.pickFiles(
                  //     allowMultiple: true,
                  //     type: FileType.custom,
                  //     allowedExtensions: ['pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx'],
                  //   );
                  //   if (result != null) {
                  //     for (var file in result.files) {
                  //       if (file.path != null) {
                  //         vm.addAttachment(file.path!);
                  //       }
                  //     }
                  //     ScaffoldMessenger.of(context).showSnackBar(
                  //       SnackBar(content: Text('Added ${result.files.length} file(s)')),
                  //     );
                  //   }
                  // },
                  icon: Icon(Icons.attach_file, size: 18.sp),
                  label: Text('Add Files', style: TextStyle(fontSize: 12.sp)),
                ),
              ],
            ),
          ),
          if (vm.localAttachments.isNotEmpty)
            Column(
              children: [
                const Divider(height: 0),
                ...vm.localAttachments.asMap().entries.map((entry) {
                  int index = entry.key;
                  String path = entry.value;
                  return ListTile(
                    leading: Icon(Icons.insert_drive_file, color: Colors.blue.shade400),
                    title: Text(vm.getAttachmentFileName(path), style: TextStyle(fontSize: 13.sp)),
                    subtitle: Text(vm.getAttachmentExtension(path).toUpperCase(), style: TextStyle(fontSize: 11.sp)),
                    trailing: IconButton(
                      icon: Icon(Icons.delete, color: Colors.red, size: 20.sp),
                      onPressed: () => vm.removeAttachment(index),
                    ),
                    dense: true,
                  );
                }),
              ],
            ),
          if (vm.localAttachments.isEmpty)
            Padding(
              padding: EdgeInsets.all(24.w),
              child: Center(
                child: Text(
                  'No attachments added',
                  style: TextStyle(color: Colors.grey, fontSize: 12.sp),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Color _getStatusColor(String? status) {
    switch (status?.toLowerCase()) {
      case 'pending':
        return Colors.orange;
      case 'in_progress':
      case 'inprogress':
        return Colors.blue;
      case 'completed':
      case 'done':
        return Colors.green;
      case 'cancelled':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        title: Text(
          "Action Points",
          style: TextStyle(fontSize: 20.sp, fontWeight: FontWeight.bold),
        ),
        elevation: 0,
        centerTitle: false,
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.grey.shade800,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.grey.shade100,
                blurRadius: 10,
                offset: Offset(0, 2),
              ),
            ],
          ),
        ),

      ),
      body: Consumer<GetActionPointViewModel>(
        builder: (context, vm, child) {
          if (vm.isLoading) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    width: 40.w,
                    height: 40.h,
                    child: CircularProgressIndicator(
                      strokeWidth: 3,
                      color: Colors.blue.shade600,
                    ),
                  ),
                  SizedBox(height: 16.h),
                  Text(
                    "Loading action points...",
                    style: TextStyle(color: Colors.grey.shade600),
                  ),
                ],
              ),
            );
          }

          if (vm.error != null) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.error_outline, size: 64.sp, color: Colors.grey.shade400),
                  SizedBox(height: 16.h),
                  Text(
                    vm.error!,
                    style: TextStyle(color: Colors.grey.shade600),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 16.h),
                  ElevatedButton.icon(
                    onPressed: () => vm.refresh(widget.meetingId),
                    icon: Icon(Icons.refresh),
                    label: Text("Retry"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue.shade600,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12.r),
                      ),
                    ),
                  ),
                ],
              ),
            );
          }

          if (vm.details.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.inbox_outlined, size: 80.sp, color: Colors.grey.shade400),
                  SizedBox(height: 16.h),
                  Text(
                    "No Action Points Found",
                    style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.w600, color: Colors.grey.shade600),
                  ),
                  SizedBox(height: 8.h),
                  Text(
                    "Tap the + button to create one",
                    style: TextStyle(fontSize: 14.sp, color: Colors.grey.shade500),
                  ),
                  SizedBox(height: 24.h),
                  ElevatedButton.icon(
                    onPressed: () => vm.refresh(widget.meetingId),
                    icon: Icon(Icons.refresh),
                    label: Text("Refresh"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue.shade600,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12.r),
                      ),
                    ),
                  ),
                ],
              ),
            );
          }

          return RefreshIndicator(
            onRefresh: () => vm.refresh(widget.meetingId),
            color: Colors.blue.shade600,
            child: CustomScrollView(
              slivers: [
                SliverToBoxAdapter(child: _buildMeetingHeader(vm)),
                SliverPadding(
                  padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
                  sliver: SliverToBoxAdapter(
                    child: _buildSectionHeader(vm.details.length),
                  ),
                ),
                SliverPadding(
                  padding: EdgeInsets.symmetric(horizontal: 16.w),
                  sliver: SliverList(
                    delegate: SliverChildBuilderDelegate(
                          (context, index) => _buildActionPointCard(vm.details[index], vm),
                      childCount: vm.details.length,
                    ),
                  ),
                ),
                if (vm.attachments.isNotEmpty)
                  SliverToBoxAdapter(child: _buildAttachmentsSectionList(vm)),
                SliverToBoxAdapter(child: SizedBox(height: 32.h)),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildSectionHeader(int count) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            Container(
              width: 4.w,
              height: 20.h,
              decoration: BoxDecoration(
                color: Colors.blue.shade600,
                borderRadius: BorderRadius.circular(2.r),
              ),
            ),
            SizedBox(width: 8.w),
            Text(
              "Action Points",
              style: TextStyle(
                fontSize: 18.sp,
                fontWeight: FontWeight.bold,
                color: Colors.grey.shade800,
              ),
            ),
            SizedBox(width: 8.w),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
              decoration: BoxDecoration(
                color: Colors.blue.shade50,
                borderRadius: BorderRadius.circular(20.r),
              ),
              child: Text(
                "$count",
                style: TextStyle(
                  fontSize: 12.sp,
                  fontWeight: FontWeight.w600,
                  color: Colors.blue.shade600,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildMeetingHeader(GetActionPointViewModel vm) {
    final meeting = vm.meeting;
    if (meeting == null) return SizedBox.shrink();

    return Container(
      margin: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.blue.shade600, Colors.blue.shade400],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20.r),
        boxShadow: [
          BoxShadow(
            color: Colors.blue.shade200,
            blurRadius: 20.r,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.all(20.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 6.h),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(20.r),
                  ),
                  child: Text(
                    meeting.meetingCode ?? "N/A",
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12.sp),
                  ),
                ),
                Spacer(),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 6.h),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(20.r),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.calendar_today, size: 12.sp, color: Colors.white),
                      SizedBox(width: 4.w),
                      Text(
                        meeting.meetingDate ?? "No Date",
                        style: TextStyle(color: Colors.white, fontSize: 12.sp),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 16.h),
            Text(
              meeting.meetingType ?? "Meeting",
              style: TextStyle(color: Colors.white, fontSize: 22.sp, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 12.h),
            Row(
              children: [
                Icon(Icons.person, size: 14.sp, color: Colors.white70),
                SizedBox(width: 8.w),
                Text(
                  "Created by: ${meeting.createdByName ?? "Unknown"}",
                  style: TextStyle(color: Colors.white70, fontSize: 13.sp),
                ),
              ],
            ),
            if (meeting.projectName != null) ...[
              SizedBox(height: 8.h),
              Row(
                children: [
                  Icon(Icons.business, size: 14.sp, color: Colors.white70),
                  SizedBox(width: 8.w),
                  Text(
                    "Project: ${meeting.projectName}",
                    style: TextStyle(color: Colors.white70, fontSize: 13.sp),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  // Enhanced Action Point Card - Shows ALL fields
  Widget _buildActionPointCard(Details item, GetActionPointViewModel vm) {
    final statusColor = _getStatusColor(item.status);
    final statusIcon = _getStatusIcon(item.status);

    return Container(
      margin: EdgeInsets.only(bottom: 12.h),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16.r),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade100,
            blurRadius: 10.r,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(16.r),
        child: InkWell(
          // onTap: () => _showEditDialog(context, item),
          borderRadius: BorderRadius.circular(16.r),
          child: Padding(
            padding: EdgeInsets.all(16.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header with status and actions
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 4.w,
                      height: 60.h,
                      decoration: BoxDecoration(
                        color: statusColor,
                        borderRadius: BorderRadius.circular(2.r),
                      ),
                    ),
                    SizedBox(width: 12.w),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Description
                          Text(
                            item.description ?? "No Description",
                            style: TextStyle(
                                fontSize: 16.sp,
                                fontWeight: FontWeight.bold,
                                color: Colors.grey.shade800
                            ),
                            maxLines: 3,
                            overflow: TextOverflow.ellipsis,
                          ),
                          SizedBox(height: 8.h),

                          // Status and Target Date Chips
                          Wrap(
                            spacing: 8.w,
                            runSpacing: 8.h,
                            children: [
                              _buildStatusChip(item.status ?? "Unknown", statusColor, statusIcon),
                              if (item.targetDate != null)
                                _buildDateChip(item.targetDate!),
                              // Action Point ID Chip
                              _buildInfoChip(
                                "ID: ${item.actionPointId ?? item.id ?? 'N/A'}",
                                Icons.tag,
                                Colors.purple,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    // Edit/Delete buttons
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // _buildActionButton(Icons.edit, Colors.blue, () => _showEditDialog(context, item)),
                        SizedBox(width: 8.w),
                        _buildActionButton(Icons.delete_outline, Colors.red,
                                () => _showDeleteConfirmation(context, item.id ?? "", item.description ?? "")),
                      ],
                    ),
                  ],
                ),

                SizedBox(height: 16.h),
                Divider(color: Colors.grey.shade100),
                SizedBox(height: 16.h),

                // Detailed Information Grid
                _buildDetailedInfoGrid(item),

                SizedBox(height: 12.h),
                Divider(color: Colors.grey.shade100),
                SizedBox(height: 12.h),

                // Metadata (Created/Updated info)
                _buildMetadataSection(item),
              ],
            ),
          ),
        ),
      ),
    );
  }

// New: Detailed Info Grid showing all fields
  Widget _buildDetailedInfoGrid(Details item) {
    return GridView.count(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      mainAxisSpacing: 12.h,
      crossAxisSpacing: 12.w,
      childAspectRatio: 2.5,
      children: [
        _buildDetailedInfoItem(
          "Assigned To",
          item.assignedEmployeeName ?? "Unassigned",
          Icons.person_outline,
          Colors.blue,
        ),
        _buildDetailedInfoItem(
          "Sub Project",
          item.subProjectName?.toString() ?? "Not Assigned",
          Icons.account_tree_outlined,
          Colors.green,
        ),
        _buildDetailedInfoItem(
          "Status",
          item.status ?? "Unknown",
          Icons.flag,
          _getStatusColor(item.status),
        ),
        _buildDetailedInfoItem(
          "Target Date",
          item.targetDate ?? "No date",
          Icons.calendar_today,
          Colors.orange,
        ),
        if (item.id != null)
          _buildDetailedInfoItem(
            "Action Point ID",
            item.id!,
            Icons.numbers,
            Colors.purple,
          ),
        if (item.actionPointId != null && item.actionPointId != item.id)
          _buildDetailedInfoItem(
            "Reference ID",
            item.actionPointId!,
            Icons.link,
            Colors.teal,
          ),
      ],
    );
  }

// Helper: Detailed info item
  Widget _buildDetailedInfoItem(String label, String value, IconData icon, Color color) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 2.h, horizontal: 12.w),
      decoration: BoxDecoration(
        color: color.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(6.w),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8.r),
            ),
            child: Icon(icon, size: 16.sp, color: color),
          ),
          SizedBox(width: 12.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 10.sp,
                    color: Colors.grey.shade500,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 2.h),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 12.sp,
                    fontWeight: FontWeight.w600,
                    color: Colors.grey.shade800,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

// New: Metadata section showing created/updated info
  Widget _buildMetadataSection(Details item) {
    return Row(
      children: [
        Expanded(
          child: _buildMetadataItem(
            "Created By",
            item.createdBy ?? "Unknown",
            item.createdOn ?? "Unknown date",
            Icons.person_add,
            Colors.green,
          ),
        ),
        SizedBox(width: 12.w),
        Expanded(
          child: _buildMetadataItem(
            "Last Updated",
            item.updatedOn != null ? "Updated" : "Not updated",
            item.updatedOn ?? item.createdOn ?? "Unknown",
            Icons.update,
            Colors.orange,
          ),
        ),
      ],
    );
  }

// Helper: Metadata item
  Widget _buildMetadataItem(String label, String user, String date, IconData icon, Color color) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 8.h, horizontal: 12.w),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(12.r),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 12.sp, color: color),
              SizedBox(width: 4.w),
              Text(
                label,
                style: TextStyle(
                  fontSize: 10.sp,
                  color: Colors.grey.shade600,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
          SizedBox(height: 4.h),
          Text(
            user,
            style: TextStyle(
              fontSize: 12.sp,
              fontWeight: FontWeight.w600,
              color: Colors.grey.shade800,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          Text(
            _formatDate(date),
            style: TextStyle(
              fontSize: 10.sp,
              color: Colors.grey.shade500,
            ),
          ),
        ],
      ),
    );
  }

// Helper: Info chip
  Widget _buildInfoChip(String text, IconData icon, Color color) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 10.sp, color: color),
          SizedBox(width: 4.w),
          Text(
            text,
            style: TextStyle(
              fontSize: 10.sp,
              fontWeight: FontWeight.w500,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

// Helper: Format date properly
  String _formatDate(String? dateString) {
    if (dateString == null) return "Unknown";
    try {
      // Try to parse and format date
      DateTime date = DateTime.parse(dateString);
      return "${date.day}/${date.month}/${date.year}";
    } catch (e) {
      return dateString;
    }
  }

  Widget _buildStatusChip(String status, Color color, IconData icon) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12.sp, color: color),
          SizedBox(width: 4.w),
          Text(status, style: TextStyle(fontSize: 11.sp, fontWeight: FontWeight.w500, color: color)),
        ],
      ),
    );
  }

  Widget _buildDateChip(String date) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
      decoration: BoxDecoration(
        color: Colors.grey.shade100,
        borderRadius: BorderRadius.circular(12.r),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.event, size: 12.sp, color: Colors.grey.shade600),
          SizedBox(width: 4.w),
          Text(date, style: TextStyle(fontSize: 11.sp, color: Colors.grey.shade600)),
        ],
      ),
    );
  }

  Widget _buildActionButton(IconData icon, Color color, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20.r),
      child: Container(
        padding: EdgeInsets.all(8.w),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          shape: BoxShape.circle,
        ),
        child: Icon(icon, size: 18.sp, color: color),
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 6.h, horizontal: 10.w),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(8.r),
      ),
      child: Row(
        children: [
          Icon(icon, size: 14.sp, color: Colors.grey.shade500),
          SizedBox(width: 8.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: TextStyle(fontSize: 10.sp, color: Colors.grey.shade500)),
                Text(value, style: TextStyle(fontSize: 12.sp, fontWeight: FontWeight.w500, color: Colors.grey.shade700), maxLines: 1, overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
        ],
      ),
    );
  }

  IconData _getStatusIcon(String? status) {
    switch (status?.toLowerCase()) {
      case 'completed':
        return Icons.check_circle;
      case 'in progress':
        return Icons.play_circle;
      case 'pending':
        return Icons.pending;
      default:
        return Icons.help_outline;
    }
  }

  Widget _buildAttachmentsSectionList(GetActionPointViewModel vm) {
    return Container(
      margin: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16.r),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade100,
            blurRadius: 10.r,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.all(16.w),
            child: Row(
              children: [
                Icon(Icons.attach_file, color: Colors.blue.shade600),
                SizedBox(width: 8.w),
                Text(
                  "Attachments",
                  style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.bold, color: Colors.grey.shade800),
                ),
                Spacer(),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                  decoration: BoxDecoration(
                    color: Colors.blue.shade50,
                    borderRadius: BorderRadius.circular(20.r),
                  ),
                  child: Text(
                    "${vm.attachments.length}",
                    style: TextStyle(fontSize: 12.sp, fontWeight: FontWeight.w600, color: Colors.blue.shade600),
                  ),
                ),
              ],
            ),
          ),
          Divider(color: Colors.grey.shade100, height: 0),
          ListView.separated(
            itemCount: vm.attachments.length,
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            separatorBuilder: (context, index) => Divider(color: Colors.grey.shade100, height: 0),
            itemBuilder: (context, index) {
              final file = vm.attachments[index];
              return ListTile(
                leading: Container(
                  padding: EdgeInsets.all(8.w),
                  decoration: BoxDecoration(
                    color: Colors.blue.shade50,
                    borderRadius: BorderRadius.circular(8.r),
                  ),
                  child: Icon(Icons.insert_drive_file, color: Colors.blue.shade400, size: 20.sp),
                ),
                title: Text(file.fileName ?? "Unnamed File", style: TextStyle(fontWeight: FontWeight.w500, fontSize: 14.sp)),
                subtitle: Text("Uploaded by: ${file.uploadedByName ?? "Unknown"}", style: TextStyle(fontSize: 12.sp, color: Colors.grey.shade600)),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: Icon(Icons.download, color: Colors.grey.shade600, size: 20.sp),
                      onPressed: () => print("Download file: ${file.filePath}"),
                    ),
                    IconButton(
                      icon: Icon(Icons.delete_outline, color: Colors.red.shade400, size: 20.sp),
                      onPressed: () => _showDeleteAttachmentDialog(context),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  void _showDeleteAttachmentDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16.r)),
        title: Text("Delete Attachment", style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.bold)),
        content: Text("Are you sure you want to delete this attachment?", style: TextStyle(fontSize: 14.sp)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text("Cancel")),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Attachment deleted")));
            },
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: Text("Delete"),
          ),
        ],
      ),
    );
  }
}