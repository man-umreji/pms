import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../meating_action_point_screen/model/meating_action_point_model.dart' as emp;
import '../../meating_action_point_screen/repository/meating_action_point_repo.dart';
import '../model/get_action_point_model.dart';
import '../model/update_action_point_model.dart';
import '../view_model/get_action_view_view_model.dart';

/// Edit all action points for a meeting (same field pattern as [MeetingActionPointView]).
class ActionPointFormScreen extends StatefulWidget {
  final GetActionPointViewModel viewModel;
  final int meetingId;

  const ActionPointFormScreen({
    super.key,
    required this.viewModel,
    required this.meetingId,
  });

  @override
  State<ActionPointFormScreen> createState() => _ActionPointFormScreenState();
}

class _ActionPointFormScreenState extends State<ActionPointFormScreen> {
  final _formKey = GlobalKey<FormState>();

  List<TextEditingController> _descControllers = [];
  List<TextEditingController> _dateControllers = [];
  List<String?> _assigneeIds = [];

  final TextEditingController _remarkController = TextEditingController();

  List<emp.Data> _employees = [];
  bool _loadingEmployees = true;
  bool _submitting = false;

  @override
  void initState() {
    super.initState();
    _syncControllersFromViewModel();
    _loadEmployees();
  }

  void _syncControllersFromViewModel() {
    for (final c in _descControllers) {
      c.dispose();
    }
    for (final c in _dateControllers) {
      c.dispose();
    }
    final list = widget.viewModel.details;
    _descControllers =
        list.map((e) => TextEditingController(text: e.description ?? '')).toList();
    _dateControllers = list
        .map((e) => TextEditingController(text: _formatDateForField(e.targetDate)))
        .toList();
    _assigneeIds = list.map((e) => e.assignedTo).toList();
  }

  String _formatDateForField(String? raw) {
    if (raw == null || raw.isEmpty || raw == '0000-00-00') return '';
    final iso = DateTime.tryParse(raw);
    if (iso != null) {
      return '${iso.day.toString().padLeft(2, '0')}/${iso.month.toString().padLeft(2, '0')}/${iso.year}';
    }
    if (raw.contains('/')) return raw;
    return raw;
  }

  Future<void> _loadEmployees() async {
    final m = widget.viewModel.meeting;
    if (m?.meetingTypeId == null) {
      setState(() => _loadingEmployees = false);
      return;
    }
    setState(() => _loadingEmployees = true);
    try {
      final repo = SelectEmployeeRepository();
      final res = await repo.getEmployees(
        emp.SelectEmployeeReqModel(
          meatingTypeId: m!.meetingTypeId,
          projectId: m.projectId?.toString() ?? '1',
        ),
      );
      if (!mounted) return;
      if (res.status == true && res.data != null) {
        setState(() => _employees = res.data!);
      }
    } finally {
      if (mounted) setState(() => _loadingEmployees = false);
    }
  }

  Future<void> _pickDate(int index) async {
    DateTime initial = DateTime.now();
    final t = _dateControllers[index].text.trim();
    if (t.isNotEmpty) {
      final parts = t.split('/');
      if (parts.length == 3) {
        final d = int.tryParse(parts[0]);
        final m = int.tryParse(parts[1]);
        final y = int.tryParse(parts[2]);
        if (d != null && m != null && y != null) {
          initial = DateTime(y, m, d);
        }
      }
    }
    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(2020),
      lastDate: DateTime(2035),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.light(
              primary: Colors.blue.shade700,
              onPrimary: Colors.white,
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null && mounted) {
      final formatted =
          '${picked.day.toString().padLeft(2, '0')}/${picked.month.toString().padLeft(2, '0')}/${picked.year}';
      setState(() => _dateControllers[index].text = formatted);
    }
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    final details = widget.viewModel.details;
    if (details.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No action points to update')),
      );
      return;
    }
    for (int i = 0; i < details.length; i++) {
      if ((_assigneeIds[i] ?? '').isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Select assignee for item ${i + 1}')),
        );
        return;
      }
    }

    setState(() => _submitting = true);
    final items = <ActionPointItem>[];
    for (int i = 0; i < details.length; i++) {
      final orig = details[i];
      items.add(
        ActionPointItem(
          id: orig.id,
          description: _descControllers[i].text.trim(),
          targetDate: _dateControllers[i].text.trim(),
          assignedTo: _assigneeIds[i],
          status: orig.status,
        ),
      );
    }

    final ok = await widget.viewModel.bulkUpdateActionPoints(
      actionPoints: items,
      remark: _remarkController.text.trim(),
    );
    if (!mounted) return;
    setState(() => _submitting = false);

    if (ok) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(widget.viewModel.updateMessage ?? 'Updated'),
          backgroundColor: Colors.green,
        ),
      );
      Navigator.pop(context, true);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(widget.viewModel.updateMessage ?? 'Update failed'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  void dispose() {
    for (final c in _descControllers) {
      c.dispose();
    }
    for (final c in _dateControllers) {
      c.dispose();
    }
    _remarkController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final vm = widget.viewModel;
    final meeting = vm.meeting;
    final details = vm.details;

    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: Text(
          'Edit action points',
          style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.blue.shade700,
        foregroundColor: Colors.white,
      ),
      body: vm.isLoading && details.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : Form(
              key: _formKey,
              child: SingleChildScrollView(
                padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 16.h),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildMeetingHeader(meeting),
                    SizedBox(height: 16.h),
                    Text(
                      'Suggested action points',
                      style: TextStyle(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.bold,
                        color: Colors.grey.shade800,
                      ),
                    ),
                    SizedBox(height: 8.h),
                    if (details.isEmpty)
                      Padding(
                        padding: EdgeInsets.all(24.r),
                        child: Center(
                          child: Text(
                            'No action points for this meeting.',
                            style: TextStyle(color: Colors.grey.shade600),
                          ),
                        ),
                      )
                    else
                      ...List.generate(details.length, (index) {
                        return Padding(
                          padding: EdgeInsets.only(bottom: 12.h),
                          child: _buildActionPointCard(
                            context,
                            index,
                            details[index],
                          ),
                        );
                      }),
                    SizedBox(height: 8.h),
                    _buildFieldLabel('Remark', Icons.comment_outlined),
                    TextFormField(
                      controller: _remarkController,
                      maxLines: 3,
                      style: TextStyle(fontSize: 14.sp),
                      decoration: _inputDecoration(
                        hintText: 'Remark for this update (required)',
                        prefixIcon: Icons.comment,
                      ),
                      validator: (v) {
                        if (v == null || v.trim().length < 3) {
                          return 'Remark is required (min 3 characters)';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 24.h),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _submitting || details.isEmpty ? null : _submit,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green.shade700,
                          foregroundColor: Colors.white,
                          padding: EdgeInsets.symmetric(vertical: 14.h),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14.r),
                          ),
                        ),
                        child: _submitting
                            ? SizedBox(
                                height: 22.h,
                                width: 22.w,
                                child: const CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : Text(
                                'Save changes',
                                style: TextStyle(
                                  fontSize: 16.sp,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                      ),
                    ),
                    SizedBox(height: 24.h),
                  ],
                ),
              ),
            ),
    );
  }

  Widget _buildMeetingHeader(Meeting? meeting) {
    if (meeting == null) return const SizedBox.shrink();
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(16.r),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.blue.shade700, Colors.blue.shade500],
        ),
        borderRadius: BorderRadius.circular(16.r),
        boxShadow: [
          BoxShadow(
            color: Colors.blue.shade200,
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            meeting.meetingType ?? 'Meeting',
            style: TextStyle(
              fontSize: 16.sp,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          if (meeting.meetingCode != null) ...[
            SizedBox(height: 4.h),
            Text(
              meeting.meetingCode!,
              style: TextStyle(fontSize: 12.sp, color: Colors.white70),
            ),
          ],
          if (meeting.meetingDate != null &&
              meeting.meetingDate!.isNotEmpty &&
              meeting.meetingDate != '0000-00-00') ...[
            SizedBox(height: 8.h),
            Text(
              'Meeting date: ${meeting.meetingDate}',
              style: TextStyle(fontSize: 12.sp, color: Colors.white70),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildFieldLabel(String text, IconData icon) {
    return Padding(
      padding: EdgeInsets.only(bottom: 8.h),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(4.r),
            decoration: BoxDecoration(
              color: Colors.blue.shade50,
              borderRadius: BorderRadius.circular(8.r),
            ),
            child: Icon(icon, size: 16.sp, color: Colors.blue.shade700),
          ),
          SizedBox(width: 8.w),
          Text(
            text,
            style: TextStyle(
              fontSize: 14.sp,
              fontWeight: FontWeight.w600,
              color: Colors.grey.shade800,
            ),
          ),
        ],
      ),
    );
  }

  InputDecoration _inputDecoration({
    required String hintText,
    IconData? prefixIcon,
  }) {
    return InputDecoration(
      hintText: hintText,
      hintStyle: TextStyle(color: Colors.grey.shade400, fontSize: 14.sp),
      prefixIcon: prefixIcon != null
          ? Icon(prefixIcon, color: Colors.blue.shade700, size: 20.sp)
          : null,
      filled: true,
      fillColor: Colors.grey.shade50,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14.r),
        borderSide: BorderSide.none,
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14.r),
        borderSide: BorderSide.none,
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14.r),
        borderSide: BorderSide(color: Colors.blue.shade700, width: 2),
      ),
      contentPadding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 14.h),
    );
  }

  Widget _buildActionPointCard(
    BuildContext context,
    int index,
    Details point,
  ) {
    final ids = _employees.map((e) => e.id).toSet();
    String? ddValue = _assigneeIds[index];
    if (ddValue != null && !ids.contains(ddValue)) {
      ddValue = null;
    }

    return Container(
      padding: EdgeInsets.all(16.r),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14.r),
        border: Border.all(color: Colors.grey.shade200),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade100,
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: EdgeInsets.all(8.r),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.blue.shade400, Colors.blue.shade700],
                  ),
                  borderRadius: BorderRadius.circular(10.r),
                ),
                child: Text(
                  '${index + 1}',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    fontSize: 12.sp,
                  ),
                ),
              ),
              SizedBox(width: 12.w),
              Expanded(
                child: Text(
                  'Action point',
                  style: TextStyle(
                    fontSize: 12.sp,
                    fontWeight: FontWeight.w600,
                    color: Colors.grey.shade600,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 12.h),
          _buildFieldLabel('Description', Icons.description_outlined),
          TextFormField(
            controller: _descControllers[index],
            maxLines: 3,
            style: TextStyle(fontSize: 14.sp),
            decoration: _inputDecoration(
              hintText: 'Description',
              prefixIcon: Icons.subject,
            ),
            validator: (v) {
              if (v == null || v.trim().length < 3) {
                return 'Description required';
              }
              return null;
            },
          ),
          SizedBox(height: 12.h),
          _buildFieldLabel('Assign to employee', Icons.person_outline),
          if (_loadingEmployees)
            LinearProgressIndicator(color: Colors.blue.shade700)
          else if (_employees.isEmpty)
            TextField(
              readOnly: true,
              maxLines: 1,
              decoration: _inputDecoration(
                hintText: point.assignedEmployeeName ?? 'Assignee',
                prefixIcon: Icons.person_outline,
              ).copyWith(
                hintText: point.assignedEmployeeName ?? 'No employee list — reopen after sync',
              ),
            )
          else
            DropdownButtonFormField<String>(
              value: ddValue,
              isExpanded: true,
              hint: Text(
                'Select employee',
                style: TextStyle(color: Colors.grey.shade400, fontSize: 14.sp),
              ),
              items: _employees.map((e) {
                return DropdownMenuItem<String>(
                  value: e.id,
                  child: Text(
                    e.employeeName ?? '',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 14.sp),
                  ),
                );
              }).toList(),
              onChanged: (v) {
                setState(() => _assigneeIds[index] = v);
              },
              icon: Icon(Icons.arrow_drop_down, color: Colors.blue.shade700),
              dropdownColor: Colors.white,
              borderRadius: BorderRadius.circular(14.r),
              decoration: _inputDecoration(
                hintText: 'Select employee',
                prefixIcon: Icons.person_outline,
              ),
            ),
          SizedBox(height: 12.h),
          _buildFieldLabel('Assigned date', Icons.event_outlined),
          TextFormField(
            key: ValueKey('upd_date_${index}_${point.id}'),
            controller: _dateControllers[index],
            readOnly: true,
            maxLines: 1,
            style: TextStyle(fontSize: 14.sp),
            onTap: () => _pickDate(index),
            decoration: _inputDecoration(
              hintText: 'Select date',
              prefixIcon: Icons.calendar_today,
            ).copyWith(
              suffixIcon: Icon(Icons.arrow_drop_down, color: Colors.grey.shade400),
            ),
            validator: (v) {
              if (v == null || v.trim().isEmpty) {
                return 'Date required';
              }
              return null;
            },
          ),
        ],
      ),
    );
  }
}
