class GenerateActionPointAiReqModel {
  String? meatingNotes;
  String? meatingDate;
  String? projectId;
  String? meatingTypeId;


  GenerateActionPointAiReqModel({
    this.meatingNotes,
    this.meatingDate,
    this.projectId,
    this.meatingTypeId,
  });

  Map<String, dynamic> toJson() => {
    "meeting_notes": meatingNotes,
    "meeting_date": meatingDate,
    "project_id": projectId,
    "meeting_type_id": meatingTypeId,
  };
}
class GenerateActionPointAiResModel {
  bool? success;
  String? source;
  List<ActionPoints>? actionPoints;
  String? meetingTypeCode;
  String? projectHint;
  String? meetingDate;

  GenerateActionPointAiResModel(
      {this.success,
        this.source,
        this.actionPoints,
        this.meetingTypeCode,
        this.projectHint,
        this.meetingDate});

  GenerateActionPointAiResModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    source = json['source'];
    if (json['action_points'] != null) {
      actionPoints = <ActionPoints>[];
      json['action_points'].forEach((v) {
        actionPoints!.add(new ActionPoints.fromJson(v));
      });
    }
    meetingTypeCode = json['meeting_type_code'];
    projectHint = json['project_hint'];
    meetingDate = json['meeting_date'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['success'] = this.success;
    data['source'] = this.source;
    if (this.actionPoints != null) {
      data['action_points'] =
          this.actionPoints!.map((v) => v.toJson()).toList();
    }
    data['meeting_type_code'] = this.meetingTypeCode;
    data['project_hint'] = this.projectHint;
    data['meeting_date'] = this.meetingDate;
    return data;
  }
}

class ActionPoints {
  String? description;
  String? targetDate;
  String? assigneeName;
  /// Set in-app when user picks an employee; sent as [assigned_to] when saving.
  String? assignedToId;

  ActionPoints({
    this.description,
    this.targetDate,
    this.assigneeName,
    this.assignedToId,
  });

  ActionPoints.fromJson(Map<String, dynamic> json) {
    description = json['description'];
    targetDate = json['target_date'];
    assigneeName = json['assignee_name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['description'] = this.description;
    data['target_date'] = this.targetDate;
    data['assignee_name'] = this.assigneeName;
    return data;
  }
}