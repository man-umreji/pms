import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import '../../meating_screen/model/meating_model.dart';
import '../model/generate_action_point_ai_model.dart';
import '../model/meating_action_point_model.dart';
import '../view_mode/meating_action_point_view_model.dart';

class MeetingActionPointView extends StatefulWidget {
  const MeetingActionPointView({super.key});

  @override
  State<MeetingActionPointView> createState() =>
      _MeetingActionPointViewState();
}

class _MeetingActionPointViewState extends State<MeetingActionPointView> {
  late stt.SpeechToText _speech;
  bool _isListening = false;
  
  String _text = '';

  double _soundLevel = 0.0;

  @override
  void initState() {
    super.initState();
    _initSpeech();

    Future.microtask(() {
      context.read<MeatingActionPointViewModel>().fetchMeetingTypes();
    });
  }

  void _initSpeech() {
    _speech = stt.SpeechToText();
  }

  void _startListening(TextEditingController controller) async {
    bool available = await _speech.initialize(
      onStatus: (status) {
        print('Speech status: $status');
        if (status == 'done' || status == 'notListening') {
          setState(() {
            _isListening = false;
            _soundLevel = 0.0;
          });
        }
      },
      onError: (error) {
        print('Speech error: $error');
        setState(() {
          _isListening = false;
          _soundLevel = 0.0;
        });
      },
    );

    if (available) {
      setState(() {
        _isListening = true;
        _soundLevel = 0.0;
      });
      _speech.listen(
        onResult: (result) {
          setState(() {
            _text = result.recognizedWords;
            controller.text = _text;
          });
        },

        listenFor: Duration(seconds: 30),
        pauseFor: Duration(seconds: 5),
        partialResults: true,
        localeId: 'en_US',
        onSoundLevelChange: (level) {
          setState(() {
            _soundLevel = level;
          });
        },
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Speech recognition not available")),
      );
    }
  }

  void _stopListening() {
    if (_isListening) {
      _speech.stop();
      setState(() {
        _isListening = false;
        _soundLevel = 0.0;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: _buildAppBar(),
      body: Consumer<MeatingActionPointViewModel>(
        builder: (context, vm, child) {
          if (vm.isLoading) {
            return _buildLoadingState();
          }

          if (vm.error != null) {
            return _buildErrorState(vm.error!);
          }

          return SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 16.h),

                /// Header Section
                _buildHeaderSection(),

                SizedBox(height: 24.h),

                /// Main Content Container
                Container(
                  margin: EdgeInsets.symmetric(horizontal: 16.w),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20.r),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.shade200,
                        blurRadius: 10,
                        offset: const Offset(0, 5),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 24.h),

                      /// MEETING TYPE
                      _buildModernLabel("Meeting Type", Icons.meeting_room),
                      _buildModernDropdownMeeting(vm),

                      /// Divider
                      _buildDivider(),

                      /// MEETING DATE
                      _buildModernLabel("Meeting Date", Icons.calendar_today),
                      _buildModernDateField(vm.dateController),

                      /// Divider
                      _buildDivider(),

                      /// CC EMAIL
                      _buildModernLabel("CC Email (Optional)", Icons.email),
                      _buildModernTextField(vm.ccController, "Enter email address",
                          prefixIcon: Icons.email_outlined),

                      /// Divider
                      _buildDivider(),

                      /// MEETING NOTES
                      _buildModernLabel("Meeting Notes", Icons.description),
                      _buildModernVoiceTextField(vm.notesController, "Record or type meeting notes..."),

                      SizedBox(height: 24.h),

                      /// GENERATE BUTTON
                      _buildGenerateButton(vm),

                      SizedBox(height: 16.h),

                      /// AI LOADING & ERROR
                      if (vm.isAiLoading) _buildAiLoadingIndicator(),
                      if (vm.aiError != null) _buildAiError(vm.aiError!),

                      /// ACTION POINTS SECTION
                      if (vm.actionPoints.isNotEmpty) ...[
                        SizedBox(height: 16.h),
                        _buildActionPointsHeader(vm), // Pass vm here
                        _buildModernActionPointsList(vm),
                      ],

                      SizedBox(height: 24.h),

                      /// EMPLOYEE SECTION
                      // _buildModernLabel("Assign to Employee", Icons.person),
                      // _buildModernDropdownEmployee(vm),

                      if (vm.isProjectMeetingSelected) ...[
                        _buildDivider(),
                        _buildModernLabel("Project Name", Icons.folder_special),
                        _buildModernTextField(
                          vm.projectNameController,
                          "Enter project name",
                          prefixIcon: Icons.folder_outlined,
                        ),
                        _buildDivider(),
                        _buildModernLabel(
                            "Project Manager Name", Icons.manage_accounts),
                        _buildModernTextField(
                          vm.projectManagerNameController,
                          "Enter project manager name",
                          prefixIcon: Icons.person_outline,
                        ),
                      ],

                      _buildAttachmentsSection(vm),

                      SizedBox(height: 32.h),

                      /// SAVE BUTTON
                      _buildSaveButton(),

                      SizedBox(height: 24.h),
                    ],

                  ),
                ),

                SizedBox(height: 30.h),
              ],
            ),
          );
        },
      ),
    );
  }

  // ================= MODERN APP BAR =================
  AppBar _buildAppBar() {
    return AppBar(
      leading: Padding(
        padding:  EdgeInsets.only(left: 18.w),
        child: GestureDetector(
            onTap: (){
              Navigator.pop(context);
            },
            child: Icon(Icons.arrow_back_ios,color: Colors.white,)),
      ),

      title: Text(
        "Action Points",
        style: TextStyle(
          fontSize: 24.sp,
          fontWeight: FontWeight.bold,
          color: Colors.white,
        ),
      ),
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: true,
      flexibleSpace: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.blue.shade800, Colors.blue.shade600, Colors.blue.shade400],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: const BorderRadius.vertical(
            bottom: Radius.circular(25),
          ),
        ),
      ),
    );
  }

  // ================= HEADER SECTION =================
  Widget _buildHeaderSection() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16.w),
      padding: EdgeInsets.all(20.r),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.blue.shade700, Colors.blue.shade500, Colors.blue.shade400],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20.r),
        boxShadow: [
          BoxShadow(
            color: Colors.blue.shade200,
            blurRadius: 15,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(12.r),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(15.r),
            ),
            child: Icon(
              Icons.auto_awesome,
              color: Colors.white,
              size: 28.sp,
            ),
          ),
          SizedBox(width: 16.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "AI Action Generator",
                  style: TextStyle(
                    fontSize: 18.sp,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: 4.h),
                Text(
                  "Transform meeting notes into actionable tasks",
                  style: TextStyle(
                    fontSize: 12.sp,
                    color: Colors.white.withOpacity(0.9),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ================= MODERN LABEL =================
  Widget _buildModernLabel(String text, IconData icon) {
    return Padding(
      padding: EdgeInsets.only(left: 20.w, right: 20.w, bottom: 8.h),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(4.r),
            decoration: BoxDecoration(
              color: Colors.blue.shade50,
              borderRadius: BorderRadius.circular(8.r),
            ),
            child: Icon(icon, size: 16.sp, color: Colors.blue.shade700),
          ),
          SizedBox(width: 8.w),
          Text(
            text,
            style: TextStyle(
              fontSize: 14.sp,
              fontWeight: FontWeight.w600,
              color: Colors.grey.shade800,
              letterSpacing: 0.3,
            ),
          ),
        ],
      ),
    );
  }

  // ================= MODERN DROPDOWN (MEETING) =================
  Widget _buildModernDropdownMeeting(MeatingActionPointViewModel vm) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 8.h),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.grey.shade50,
          border: Border.all(color: Colors.grey.shade200),
          borderRadius: BorderRadius.circular(14.r),
        ),
        child: DropdownButtonFormField<MeetingType>(
          value: vm.meetingTypes.contains(vm.selectedMeetingType)
              ? vm.selectedMeetingType
              : null,
          hint: Padding(
            padding: EdgeInsets.only(left: 12.w),
            child: Text(
              "Choose meeting type",
              style: TextStyle(color: Colors.grey.shade500, fontSize: 14.sp),
            ),
          ),
          isExpanded: true,
          items: vm.meetingTypes.map((type) {
            return DropdownMenuItem(
              value: type,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 12.w),
                child: Text(
                  type.name ?? "",
                  style: TextStyle(fontSize: 14.sp),
                ),
              ),
            );
          }).toList(),
          onChanged: (value) {
            if (value != null) {
              vm.setSelectedMeetingType(value);
            }
          },
          decoration: InputDecoration(
            border: InputBorder.none,
            contentPadding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 14.h),
          ),
          icon: Icon(Icons.arrow_drop_down, color: Colors.blue.shade700),
          dropdownColor: Colors.white,
          borderRadius: BorderRadius.circular(14.r),
        ),
      ),
    );
  }
  Widget _buildModernDateField(TextEditingController controller) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 8.h),
      child: TextFormField(
        controller: controller,
        readOnly: true,
        onTap: () async {
          final DateTime? pickedDate = await showDatePicker(
            context: context,
            initialDate: DateTime.now(),
            firstDate: DateTime(2020),
            lastDate: DateTime(2030),
            builder: (context, child) {
              return Theme(
                data: Theme.of(context).copyWith(
                  colorScheme: ColorScheme.light(
                    primary: Colors.blue.shade700,
                    onPrimary: Colors.white,
                  ),
                ),
                child: child!,
              );
            },
          );

          if (pickedDate != null) {
            String formattedDate = "${pickedDate.day.toString().padLeft(2, '0')}/${pickedDate.month.toString().padLeft(2, '0')}/${pickedDate.year}";
            controller.text = formattedDate;
            setState(() {});
          }
        },
        decoration: InputDecoration(
          hintText: "Select date",
          hintStyle: TextStyle(color: Colors.grey.shade400, fontSize: 14.sp),
          prefixIcon: Icon(Icons.calendar_today, color: Colors.blue.shade700, size: 20.sp),
          suffixIcon: Icon(Icons.arrow_drop_down, color: Colors.grey.shade400),
          filled: true,
          fillColor: Colors.grey.shade50,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14.r),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14.r),
            borderSide: BorderSide.none,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14.r),
            borderSide: BorderSide(color: Colors.blue.shade700, width: 2),
          ),
          contentPadding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 14.h),
        ),
      ),
    );
  }

  Widget _buildModernTextField(TextEditingController controller, String hint,
      {IconData? prefixIcon}) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 8.h),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(color: Colors.grey.shade400, fontSize: 14.sp),
          prefixIcon: prefixIcon != null
              ? Icon(prefixIcon, color: Colors.blue.shade700, size: 20.sp)
              : null,
          filled: true,
          fillColor: Colors.grey.shade50,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14.r),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14.r),
            borderSide: BorderSide.none,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14.r),
            borderSide: BorderSide(color: Colors.blue.shade700, width: 2),
          ),
          contentPadding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 14.h),
        ),
      ),
    );
  }
  Widget _buildModernVoiceTextField(TextEditingController controller, String hint) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 8.h),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        decoration: BoxDecoration(
          color: _isListening ? Colors.blue.shade50 : Colors.grey.shade50,
          border: Border.all(
            color: _isListening ? Colors.blue.shade400 : Colors.grey.shade200,
            width: _isListening ? 2 : 1,
          ),
          borderRadius: BorderRadius.circular(16.r),
          boxShadow: _isListening
              ? [
            BoxShadow(
              color: Colors.blue.shade200,
              blurRadius: 15,
              spreadRadius: 2,
            ),
          ]
              : [],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (_isListening) ...[
              Padding(
                padding: EdgeInsets.only(top: 12.h, left: 16.w, right: 16.w),
                child: _buildSoundWaveVisualization(),
              ),
              SizedBox(height: 8.h),
              Container(
                margin: EdgeInsets.symmetric(horizontal: 16.w),
                height: 1,
                color: Colors.blue.shade200,
              ),
            ],
            Stack(
              children: [
                TextField(
                  controller: controller,
                  maxLines: 5,
                  minLines: 3,
                  style: TextStyle(fontSize: 14.sp),
                  decoration: InputDecoration(
                    hintText: hint,
                    hintStyle: TextStyle(color: Colors.grey.shade400, fontSize: 14.sp),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.only(
                      right: 60.w,
                      left: 16.w,
                      top: 14.h,
                      bottom: 14.h,
                    ),
                  ),
                ),
                Positioned(
                  right: 8,
                  bottom: 8,
                  child: GestureDetector(
                    onTap: () {
                      if (_isListening) {
                        _stopListening();
                      } else {
                        _startListening(controller);
                      }
                    },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      padding: EdgeInsets.all(12.r),
                      decoration: BoxDecoration(
                        gradient: _isListening
                            ? LinearGradient(
                          colors: [Colors.red.shade500, Colors.red.shade700],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        )
                            : LinearGradient(
                          colors: [Colors.blue.shade500, Colors.blue.shade700],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: (_isListening ? Colors.red : Colors.blue).withOpacity(0.4),
                            blurRadius: 12,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: Icon(
                        _isListening ? Icons.mic : Icons.mic_none,
                        color: Colors.white,
                        size: 22.sp,
                      ),
                    ),
                  ),
                ),
              ],
            ),

            // Recording Indicator
            if (_isListening) ...[
              Padding(
                padding: EdgeInsets.only(left: 16.w, right: 16.w, bottom: 12.h),
                child: Row(
                  children: [
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 500),
                      width: 8.w,
                      height: 8.h,
                      decoration: BoxDecoration(
                        color: Colors.red,
                        shape: BoxShape.circle,
                      ),
                    ),
                    SizedBox(width: 8.w),
                    Text(
                      "Recording...",
                      style: TextStyle(
                        fontSize: 12.sp,
                        color: Colors.red.shade600,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const Spacer(),
                    Text(
                      "Tap mic to stop",
                      style: TextStyle(
                        fontSize: 11.sp,
                        color: Colors.grey.shade500,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  // ================= SOUND WAVE VISUALIZATION =================
  Widget _buildSoundWaveVisualization() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(15, (index) {
        double height = 10 + (_soundLevel * 30) + (index % 3) * 5;
        if (_soundLevel > 0) {
          height = 15 + (_soundLevel * 40) + (index % 5) * 3;
        }

        return AnimatedContainer(
          duration: const Duration(milliseconds: 100),
          margin: EdgeInsets.symmetric(horizontal: 2.w),
          width: 3.w,
          height: _isListening ? height.clamp(10, 40) : 10,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Colors.blue.shade400,
                Colors.blue.shade700,
              ],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
            borderRadius: BorderRadius.circular(3.r),
          ),
        );
      }),
    );
  }

  // ================= GENERATE BUTTON =================
  Widget _buildGenerateButton(MeatingActionPointViewModel vm) {
    final busy = vm.isAiLoading;
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 20.w),
      child: Opacity(
        opacity: busy ? 0.55 : 1,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          width: double.infinity,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.blue.shade600, Colors.blue.shade800],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
            borderRadius: BorderRadius.circular(14.r),
            boxShadow: [
              BoxShadow(
                color: Colors.blue.shade300,
                blurRadius: 15,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: ElevatedButton(
          onPressed: busy
              ? null
              : () {
                  vm.generateActionPoints(
                    meetingNotes: vm.notesController.text,
                    meetingDate: vm.dateController.text,
                    projectId: "1",
                  );
                },
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.transparent,
            shadowColor: Colors.transparent,
            padding: EdgeInsets.symmetric(vertical: 14.h),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14.r),
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.auto_awesome, size: 22.sp, color: Colors.white),
              SizedBox(width: 10.w),
              Text(
                'Generate Action Points',
                style: TextStyle(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
        ),
      ),
    ),
    );
  }

  Widget _buildModernDropdownEmployee(MeatingActionPointViewModel vm) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 8.h),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.grey.shade50,
          border: Border.all(color: Colors.grey.shade200),
          borderRadius: BorderRadius.circular(14.r),
        ),
        child: DropdownButtonFormField<String>(
          value: vm.getSelectedEmployeeId(), // Use the ID directly
          hint: Padding(
            padding: EdgeInsets.only(left: 12.w),
            child: Text(
              "Select employee to assign",
              style: TextStyle(color: Colors.grey.shade500, fontSize: 14.sp),
            ),
          ),
          isExpanded: true,
          items: vm.employees.map((e) {
            return DropdownMenuItem<String>(
              value: e.id, // Use ID as value
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 12.w),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 16.r,
                      backgroundColor: Colors.blue.shade100,
                      child: Text(
                        (e.employeeName?[0] ?? 'U').toUpperCase(),
                        style: TextStyle(
                          fontSize: 13.sp,
                          fontWeight: FontWeight.bold,
                          color: Colors.blue.shade700,
                        ),
                      ),
                    ),
                    SizedBox(width: 12.w),
                    Expanded(
                      child: Text(
                        e.employeeName ?? "",
                        style: TextStyle(fontSize: 14.sp),
                      ),
                    ),
                  ],
                ),
              ),
            );
          }).toList(),
          onChanged: (value) {
            if (value != null) {
              // Find the full employee object and pass it to setSelectedEmployee
              final selectedEmp = vm.employees.firstWhere(
                    (e) => e.id == value,
                orElse: () => Data(),
              );
              if (selectedEmp.id != null) {
                vm.setSelectedEmployee(selectedEmp);
              }
            }
          },
          decoration: InputDecoration(
            border: InputBorder.none,
            contentPadding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 14.h),
          ),
          icon: Icon(Icons.arrow_drop_down, color: Colors.blue.shade700),
          dropdownColor: Colors.white,
          borderRadius: BorderRadius.circular(14.r),
        ),
      ),
    );
  }

  // ================= ACTION POINTS HEADER =================
  // Fix the _buildActionPointsHeader method to accept vm parameter
  Widget _buildActionPointsHeader(MeatingActionPointViewModel vm) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 20.w),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(6.r),
            decoration: BoxDecoration(
              color: Colors.green.shade50,
              borderRadius: BorderRadius.circular(10.r),
            ),
            child: Icon(Icons.checklist, color: Colors.green.shade700, size: 18.sp),
          ),
          SizedBox(width: 10.w),
          Text(
            "Suggested action points",
            style: TextStyle(
              fontSize: 16.sp,
              fontWeight: FontWeight.bold,
              color: Colors.grey.shade800,
              letterSpacing: 0.3,
            ),
          ),
          const Spacer(),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
            decoration: BoxDecoration(
              color: Colors.blue.shade50,
              borderRadius: BorderRadius.circular(12.r),
            ),
            child: Text(
              "${vm.actionPoints.length} items",
              style: TextStyle(
                fontSize: 12.sp,
                color: Colors.blue.shade700,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ================= MODERN ACTION POINTS LIST =================
  Widget _buildModernActionPointsList(MeatingActionPointViewModel vm) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 16.w),
      child: ListView.separated(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: vm.actionPoints.length,
        separatorBuilder: (context, index) => SizedBox(height: 12.h),
        itemBuilder: (context, index) {
          final point = vm.actionPoints[index];
          return TweenAnimationBuilder(
            duration: Duration(milliseconds: 300 + (index * 50)),
            tween: Tween<double>(begin: 0, end: 1),
            builder: (context, value, child) {
              return Opacity(
                opacity: value,
                child: Transform.translate(
                  offset: Offset(0, 20 * (1 - value)),
                  child: child,
                ),
              );
            },
            child: Container(
              padding: EdgeInsets.all(16.r),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.white, Colors.grey.shade50],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(14.r),
                border: Border.all(color: Colors.grey.shade200),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.shade100,
                    blurRadius: 8,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: EdgeInsets.all(8.r),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.blue.shade400,
                              Colors.blue.shade700,
                            ],
                          ),
                          borderRadius: BorderRadius.circular(10.r),
                        ),
                        child: Text(
                          "${index + 1}",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                            fontSize: 12.sp,
                          ),
                        ),
                      ),
                      SizedBox(width: 12.w),
                      Expanded(
                        child: Text(
                          point.description ?? "",
                          style: TextStyle(
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w600,
                            color: Colors.grey.shade800,
                            height: 1.3,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 14.h),
                  Divider(
                    height: 1,
                    thickness: 1,
                    color: Colors.grey.shade200,
                  ),
                  SizedBox(height: 12.h),
                  _buildActionPointFieldLabel(
                      "Assign to employee", Icons.person_outline),
                  _buildCompactActionPointEmployeeField(vm, index, point),
                  SizedBox(height: 12.h),
                  _buildActionPointFieldLabel(
                      "Assigned date", Icons.event_outlined),
                  _buildCompactActionPointDateTextField(vm, index, point),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildActionPointFieldLabel(String text, IconData icon) {
    return Padding(
      padding: EdgeInsets.only(bottom: 8.h),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(4.r),
            decoration: BoxDecoration(
              color: Colors.blue.shade50,
              borderRadius: BorderRadius.circular(8.r),
            ),
            child: Icon(icon, size: 16.sp, color: Colors.blue.shade700),
          ),
          SizedBox(width: 8.w),
          Text(
            text,
            style: TextStyle(
              fontSize: 14.sp,
              fontWeight: FontWeight.w600,
              color: Colors.grey.shade800,
              letterSpacing: 0.3,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCompactActionPointEmployeeField(
    MeatingActionPointViewModel vm,
    int index,
    ActionPoints point,
  ) {
    final ids = vm.employees.map((e) => e.id).toSet();
    String? value = point.assignedToId;
    if (value != null && !ids.contains(value)) {
      value = null;
    }
    if (vm.employees.isEmpty) {
      return TextField(
        readOnly: true,
        maxLines: 1,
        decoration: InputDecoration(
          hintText: "No employees loaded for this meeting type",
          hintStyle: TextStyle(color: Colors.grey.shade500, fontSize: 14.sp),
          prefixIcon: Icon(Icons.person_outline,
              color: Colors.blue.shade700, size: 20.sp),
          filled: true,
          fillColor: Colors.grey.shade50,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14.r),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14.r),
            borderSide: BorderSide.none,
          ),
          contentPadding:
              EdgeInsets.symmetric(horizontal: 16.w, vertical: 14.h),
        ),
      );
    }
    return DropdownButtonFormField<String>(
      value: value,
      isExpanded: true,
      hint: Text(
        "Select employee",
        style: TextStyle(color: Colors.grey.shade400, fontSize: 14.sp),
      ),
      items: vm.employees.map((e) {
        return DropdownMenuItem<String>(
          value: e.id,
          child: Text(
            e.employeeName ?? "",
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(fontSize: 14.sp),
          ),
        );
      }).toList(),
      onChanged: (id) => vm.updateActionPointAssignee(index, id),
      icon: Icon(Icons.arrow_drop_down, color: Colors.blue.shade700),
      dropdownColor: Colors.white,
      borderRadius: BorderRadius.circular(14.r),
      decoration: InputDecoration(
        prefixIcon:
            Icon(Icons.person_outline, color: Colors.blue.shade700, size: 20.sp),
        filled: true,
        fillColor: Colors.grey.shade50,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14.r),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14.r),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14.r),
          borderSide: BorderSide(color: Colors.blue.shade700, width: 2),
        ),
        contentPadding:
            EdgeInsets.symmetric(horizontal: 8.w, vertical: 14.h),
      ),
    );
  }

  Widget _buildCompactActionPointDateTextField(
    MeatingActionPointViewModel vm,
    int index,
    ActionPoints point,
  ) {
    final hasDate =
        point.targetDate != null && point.targetDate!.trim().isNotEmpty;
    DateTime initialPicker = DateTime.now();
    if (hasDate) {
      final parts = point.targetDate!.split('/');
      if (parts.length == 3) {
        final d = int.tryParse(parts[0]);
        final m = int.tryParse(parts[1]);
        final y = int.tryParse(parts[2]);
        if (d != null && m != null && y != null) {
          initialPicker = DateTime(y, m, d);
        }
      }
    }
    return TextFormField(
      key: ValueKey('ap_date_${index}_${point.targetDate}'),
      initialValue: hasDate ? point.targetDate : null,
      readOnly: true,
      maxLines: 1,
      style: TextStyle(fontSize: 14.sp, color: Colors.grey.shade800),
      onTap: () async {
        final picked = await showDatePicker(
          context: context,
          initialDate: initialPicker,
          firstDate: DateTime(2020),
          lastDate: DateTime(2035),
          builder: (context, child) {
            return Theme(
              data: Theme.of(context).copyWith(
                colorScheme: ColorScheme.light(
                  primary: Colors.blue.shade700,
                  onPrimary: Colors.white,
                ),
              ),
              child: child!,
            );
          },
        );
        if (picked != null && mounted) {
          final formatted =
              "${picked.day.toString().padLeft(2, '0')}/${picked.month.toString().padLeft(2, '0')}/${picked.year}";
          vm.updateActionPointTargetDate(index, formatted);
        }
      },
      decoration: InputDecoration(
        hintText: "Select date",
        hintStyle: TextStyle(color: Colors.grey.shade400, fontSize: 14.sp),
        prefixIcon: Icon(Icons.calendar_today,
            color: Colors.blue.shade700, size: 20.sp),
        suffixIcon: Icon(Icons.arrow_drop_down, color: Colors.grey.shade400),
        filled: true,
        fillColor: Colors.grey.shade50,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14.r),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14.r),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14.r),
          borderSide: BorderSide(color: Colors.blue.shade700, width: 2),
        ),
        contentPadding:
            EdgeInsets.symmetric(horizontal: 16.w, vertical: 14.h),
      ),
    );
  }

  // ================= ATTACHMENTS (optional, multipart) =================
  Widget _buildAttachmentsSection(MeatingActionPointViewModel vm) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildDivider(),
        _buildModernLabel("Attachments (optional)", Icons.attach_file),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 20.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "pdf, doc, docx, xls, xlsx, jpg, jpeg, png — max 3 MB per file",
                style: TextStyle(fontSize: 12.sp, color: Colors.grey.shade600),
              ),
              SizedBox(height: 10.h),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () => _pickAttachments(vm),
                  icon: Icon(Icons.upload_file, color: Colors.blue.shade700, size: 22.sp),
                  label: Text(
                    "Add files",
                    style: TextStyle(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w600,
                      color: Colors.blue.shade700,
                    ),
                  ),
                  style: OutlinedButton.styleFrom(
                    padding: EdgeInsets.symmetric(vertical: 12.h, horizontal: 16.w),
                    side: BorderSide(color: Colors.blue.shade200),
                    backgroundColor: Colors.blue.shade50,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14.r),
                    ),
                  ),
                ),
              ),
              if (vm.attachmentPaths.isNotEmpty) ...[
                SizedBox(height: 12.h),
                ...List.generate(vm.attachmentPaths.length, (i) {
                  final p = vm.attachmentPaths[i];
                  return Padding(
                    padding: EdgeInsets.only(bottom: 8.h),
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 10.h),
                      decoration: BoxDecoration(
                        color: Colors.grey.shade50,
                        borderRadius: BorderRadius.circular(12.r),
                        border: Border.all(color: Colors.grey.shade200),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.insert_drive_file,
                              color: Colors.blue.shade700, size: 22.sp),
                          SizedBox(width: 10.w),
                          Expanded(
                            child: Text(
                              _basename(p),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(fontSize: 13.sp),
                            ),
                          ),
                          IconButton(
                            tooltip: "Remove",
                            onPressed: () => vm.removeAttachmentAt(i),
                            icon: Icon(Icons.close, size: 22.sp, color: Colors.grey.shade700),
                          ),
                        ],
                      ),
                    ),
                  );
                }),
              ],
            ],
          ),
        ),
      ],
    );
  }

  String _basename(String path) {
    final normalized = path.replaceAll("\\", "/");
    final i = normalized.lastIndexOf("/");
    return i >= 0 ? normalized.substring(i + 1) : path;
  }

  Future<void> _pickAttachments(MeatingActionPointViewModel vm) async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const [
        "pdf",
        "doc",
        "docx",
        "xls",
        "xlsx",
        "jpg",
        "jpeg",
        "png",
      ],
      allowMultiple: true,
    );
    if (result == null || !mounted) return;
    for (final f in result.files) {
      final path = f.path;
      if (path == null) continue;
      final err = vm.addAttachmentPath(path);
      if (err != null && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(err)),
        );
      }
    }
  }

  // ================= SAVE BUTTON =================
  Widget _buildSaveButton() {
    final read = context.watch<MeatingActionPointViewModel>();
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 20.w),
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.green.shade600, Colors.green.shade800],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
          borderRadius: BorderRadius.circular(14.r),
          boxShadow: [
            BoxShadow(
              color: Colors.green.shade300,
              blurRadius: 15,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: ElevatedButton(
        onPressed: (){
        //   implement save functionality here
          read.createActionPoint(projectId: "1",context:context);

        },
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.transparent,
            shadowColor: Colors.transparent,
            padding: EdgeInsets.symmetric(vertical: 14.h),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14.r),
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.save_alt, size: 20.sp, color: Colors.white),
              SizedBox(width: 10.w),
              Text(
                'Save Action Points',
                style: TextStyle(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ================= LOADING STATE =================
  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: EdgeInsets.all(20.r),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(25.r),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.shade200,
                  blurRadius: 20,
                  spreadRadius: 5,
                ),
              ],
            ),
            child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.blue.shade700),
              strokeWidth: 3,
            ),
          ),
          SizedBox(height: 24.h),
          Text(
            "Loading...",
            style: TextStyle(
              fontSize: 16.sp,
              color: Colors.grey.shade600,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  // ================= ERROR STATE =================
  Widget _buildErrorState(String error) {
    return Center(
      child: Container(
        margin: EdgeInsets.all(24.w),
        padding: EdgeInsets.all(24.r),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(24.r),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.shade200,
              blurRadius: 15,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: EdgeInsets.all(16.r),
              decoration: BoxDecoration(
                color: Colors.red.shade50,
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.error_outline, size: 48.sp, color: Colors.red.shade400),
            ),
            SizedBox(height: 20.h),
            Text(
              "Oops! Something went wrong",
              style: TextStyle(
                fontSize: 18.sp,
                fontWeight: FontWeight.bold,
                color: Colors.grey.shade800,
              ),
            ),
            SizedBox(height: 12.h),
            Text(
              error,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14.sp, color: Colors.grey.shade600),
            ),
            SizedBox(height: 24.h),
            ElevatedButton(
              onPressed: () {
                context.read<MeatingActionPointViewModel>().fetchMeetingTypes();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue.shade700,
                padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 12.h),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12.r),
                ),
              ),
              child: const Text("Try Again"),
            ),
          ],
        ),
      ),
    );
  }

  // ================= AI LOADING INDICATOR =================
  Widget _buildAiLoadingIndicator() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 20.w, vertical: 16.h),
      padding: EdgeInsets.all(16.r),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.blue.shade50, Colors.blue.shade100],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(14.r),
        border: Border.all(color: Colors.blue.shade300),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 22.w,
            height: 22.h,
            child: CircularProgressIndicator(
              strokeWidth: 2.5,
              valueColor: AlwaysStoppedAnimation<Color>(Colors.blue.shade700),
            ),
          ),
          SizedBox(width: 14.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "AI Processing",
                  style: TextStyle(
                    fontSize: 14.sp,
                    fontWeight: FontWeight.bold,
                    color: Colors.blue.shade700,
                  ),
                ),
                Text(
                  "Generating intelligent action points...",
                  style: TextStyle(
                    fontSize: 12.sp,
                    color: Colors.blue.shade600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ================= AI ERROR =================
  Widget _buildAiError(String error) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 20.w, vertical: 16.h),
      padding: EdgeInsets.all(16.r),
      decoration: BoxDecoration(
        color: Colors.red.shade50,
        borderRadius: BorderRadius.circular(14.r),
        border: Border.all(color: Colors.red.shade200),
      ),
      child: Row(
        children: [
          Icon(Icons.error_outline, color: Colors.red.shade400, size: 22.sp),
          SizedBox(width: 14.w),
          Expanded(
            child: Text(
              error,
              style: TextStyle(
                fontSize: 13.sp,
                color: Colors.red.shade700,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ================= DIVIDER =================
  Widget _buildDivider() {
    return Divider(
      height: 24.h,
      thickness: 1,
      color: Colors.grey.shade100,
      indent: 20.w,
      endIndent: 20.w,
    );
  }
}