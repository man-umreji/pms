import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

import '../../../network/end_point.dart';
import '../../../service/api_client.dart';
import '../model/create_meating_action_point_res_model.dart';

class CreateMeetingActionRepository {
  final ApiClient _apiClient = ApiClient();

  /// 🔥 CREATE ACTION POINT
  /// Server expects **form fields** (same as Postman form-data), not a JSON body.
  /// Optional [attachmentPaths]: files sent as multipart `attachments[]` (same as update flow).
  Future<CreateMeatingActionResModel> createActionPoint(
    Map<String, dynamic> body, {
    List<String> attachmentPaths = const [],
  }) async {
    try {
      final Map<String, dynamic> payload = Map<String, dynamic>.from(body);

      if (attachmentPaths.isNotEmpty) {
        final files = <http.MultipartFile>[];
        for (final path in attachmentPaths) {
          if (path.isEmpty) continue;
          final file = File(path);
          if (await file.exists()) {
            files.add(
              await http.MultipartFile.fromPath(
                'attachments[]',
                path,
              ),
            );
          }
        }
        if (files.isNotEmpty) {
          payload['attachments[]'] = files;
        }
      }

      final response = await _apiClient.post(
        Endpoint.createActionPoint,
        body: payload,
        requiresAuth: true,
        isFormData: true,
      );

      print("========== CREATE ACTION REQUEST ==========");
      print(
        "Body keys: ${payload.keys.join(', ')} attachmentCount: ${attachmentPaths.length}",
      );

      print("========== CREATE ACTION RESPONSE ==========");
      print("Status Code: ${response.statusCode}");
      print("Response: ${response.body}");

      final data = jsonDecode(response.body);

      if (response.statusCode == 200) {
        return CreateMeatingActionResModel.fromJson(data);
      } else {
        return CreateMeatingActionResModel(
          status: false,
          message: data['message'] ?? "Failed",
        );
      }
    } catch (e) {
      return CreateMeatingActionResModel(
        status: false,
        message: "Something went wrong: $e",
      );
    }
  }

  /// ✅ OPTIONAL: RETURN ONLY STATUS
  // Future<bool> createActionPointStatus(
  //     CreateMeatingActionReqModel model,
  //     ) async {
  //   final res = await createActionPoint(model);
  //   return res.status == true;
  // }
}