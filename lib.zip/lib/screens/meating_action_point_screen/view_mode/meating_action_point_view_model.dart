import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:pms/screens/dashbord/view/dashbord_view.dart';

import '../../meating_screen/model/meating_model.dart';
import '../../meating_screen/repositoty/meating_repository.dart';
import '../model/create_meating_action_point_res_model.dart';
import '../model/generate_action_point_ai_model.dart';
import '../model/meating_action_point_model.dart';
import '../repository/create_action_point_repo.dart';
import '../repository/generate_action_point_ai_repo.dart';
import '../repository/meating_action_point_repo.dart';

const _attachmentMaxBytes = 3 * 1024 * 1024;
const _attachmentAllowedExt = {
  'pdf',
  'doc',
  'docx',
  'xls',
  'xlsx',
  'jpg',
  'jpeg',
  'png',
};

class MeatingActionPointViewModel extends ChangeNotifier {
  final GetMeetingTypeRepository _meetingRepo = GetMeetingTypeRepository();
  final SelectEmployeeRepository _employeeRepo = SelectEmployeeRepository();

  final TextEditingController dateController = TextEditingController();
  final TextEditingController notesController = TextEditingController();
  final TextEditingController ccController = TextEditingController();
  final TextEditingController projectNameController = TextEditingController();
  final TextEditingController projectManagerNameController =
      TextEditingController();
  final CreateMeetingActionRepository _createRepo = CreateMeetingActionRepository();

  List<MeetingType> _meetingTypes = [];
  MeetingType? _selectedMeetingType;

  bool _isCreateLoading = false;
  String? _createError;
  String? _createSuccess;

  bool get isCreateLoading => _isCreateLoading;
  String? get createError => _createError;
  String? get createSuccess => _createSuccess;

  List<MeetingType> get meetingTypes => _meetingTypes;
  MeetingType? get selectedMeetingType => _selectedMeetingType;

  /// True when the selected meeting type is "Project Meeting" (API name, case-insensitive).
  bool get isProjectMeetingSelected {
    final name = _selectedMeetingType?.name?.toLowerCase().trim() ?? '';
    return name == 'project meeting' || name.contains('project meeting');
  }

  List<Data> _employees = [];
  String? _selectedEmployeeId; // ✅ Store ID instead of full object
  Data? get selectedEmployee => _employees.firstWhere(
        (e) => e.id == _selectedEmployeeId,
    orElse: () => Data(),
  );

  // ================= AI ACTION POINT =================
  final GenerateActionPointAiRepository _aiRepo = GenerateActionPointAiRepository();

  List<ActionPoints> _actionPoints = [];
  int _actionPointsBatchId = 0;
  bool _isAiLoading = false;
  String? _aiError;

  List<ActionPoints> get actionPoints => _actionPoints;
  int get actionPointsBatchId => _actionPointsBatchId;
  bool get isAiLoading => _isAiLoading;
  String? get aiError => _aiError;
  List<Data> get employees => _employees;

  bool _isLoading = false;
  String? _error;

  bool get isLoading => _isLoading;
  String? get error => _error;

  final List<String> _attachmentPaths = [];
  List<String> get attachmentPaths => List.unmodifiable(_attachmentPaths);

  /// Returns null on success, or an error message.
  String? addAttachmentPath(String path) {
    final trimmed = path.trim();
    if (trimmed.isEmpty) return 'Invalid file';
    final ext = trimmed.contains('.')
        ? trimmed.split('.').last.toLowerCase()
        : '';
    if (!_attachmentAllowedExt.contains(ext)) {
      return 'Allowed types: pdf, doc, docx, xls, xlsx, jpg, jpeg, png';
    }
    final file = File(trimmed);
    if (!file.existsSync()) return 'File not found';
    if (file.lengthSync() > _attachmentMaxBytes) {
      return 'Each file must be 3 MB or smaller';
    }
    if (_attachmentPaths.contains(trimmed)) return 'File already added';
    _attachmentPaths.add(trimmed);
    notifyListeners();
    return null;
  }

  void removeAttachmentAt(int index) {
    if (index < 0 || index >= _attachmentPaths.length) return;
    _attachmentPaths.removeAt(index);
    notifyListeners();
  }

  void clearAttachments() {
    _attachmentPaths.clear();
    notifyListeners();
  }

  // ================= FETCH MEETING =================
  Future<void> fetchMeetingTypes() async {
    _isLoading = true;
    notifyListeners();

    try {
      final res = await _meetingRepo.getMeetingTypes();

      if (res.success == true && res.meetingType != null) {
        _meetingTypes = res.meetingType!;
      } else {
        _meetingTypes = [];
        _error = "Failed to load meeting types";
      }
    } catch (e) {
      _meetingTypes = [];
      _error = "Error loading meeting types";
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // ================= SELECT MEETING =================
  void setSelectedMeetingType(MeetingType type) {
    _selectedMeetingType = type;

    // ✅ Clear selected employee when meeting type changes
    _selectedEmployeeId = null;

    // 🔥 CALL EMPLOYEE API
    fetchEmployees(
      meetingTypeId: type.id.toString(),
      projectId: "1",
    );

    notifyListeners();
  }

  // ================= FETCH EMPLOYEES =================
  Future<void> fetchEmployees({
    required String meetingTypeId,
    required String projectId,
  }) async {
    _isLoading = true;
    notifyListeners();

    try {
      final res = await _employeeRepo.getEmployees(
        SelectEmployeeReqModel(
          meatingTypeId: meetingTypeId,
          projectId: projectId,
        ),
      );

      if (res.status == true && res.data != null) {
        _employees = res.data!;

        // ✅ Check if previously selected employee still exists in new list
        if (_selectedEmployeeId != null &&
            !_employees.any((emp) => emp.id == _selectedEmployeeId)) {
          _selectedEmployeeId = null;
        }
      } else {
        _employees = [];
        _selectedEmployeeId = null;
        _error = res.message ?? "Failed to load employees";
      }
    } catch (e) {
      _employees = [];
      _selectedEmployeeId = null;
      _error = "Error loading employees";
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> createActionPoint({
    required String projectId,

    required BuildContext context,
  }) async {
    if (_selectedMeetingType == null) {
      _createError = "Please select meeting type";
      notifyListeners();
      return;
    }

    if (dateController.text.isEmpty) {
      _createError = "Please select meeting date";
      notifyListeners();
      return;
    }

    if (_actionPoints.isEmpty) {
      _createError = "Generate or add at least one action point";
      notifyListeners();
      return;
    }

    for (int i = 0; i < _actionPoints.length; i++) {
      final assignedId = _actionPoints[i].assignedToId ?? _selectedEmployeeId;
      if (assignedId == null || assignedId.isEmpty) {
        _createError =
            "Assign an employee to each action point (expand row ${i + 1})";
        notifyListeners();
        return;
      }
    }

    _isCreateLoading = true;
    _createError = null;
    _createSuccess = null;
    notifyListeners();

    try {
      // 🔥 STEP 1: base model
      final model = CreateMeatingActionReqModel(
        meatingDate: dateController.text,
        projectId: projectId,
        meatingTypeId: _selectedMeetingType!.id.toString(),
        ccMailId: ccController.text,
        // meatingType: "123",
      );

      // 🔥 STEP 2: base map
      final Map<String, dynamic> body = model.toJson();

      // 🔥 STEP 3: dynamic action_points
      for (int i = 0; i < _actionPoints.length; i++) {
        final point = _actionPoints[i];
        final assignedId = point.assignedToId ?? _selectedEmployeeId;

        body["action_points[$i][description]"] =
            point.description ?? "";

        body["action_points[$i][target_date]"] =
            point.targetDate ?? "";

        body["action_points[$i][assigned_to]"] = assignedId!;
      }

      // 🔥 DEBUG
      print("========= FINAL BODY =========");
      print(body);

      // 🔥 STEP 4: API call
      final res = await _createRepo.createActionPoint(
        body,
        attachmentPaths: List<String>.from(_attachmentPaths),
      );

      if (res.status == true) {
        _createSuccess = res.message ?? "Created successfully";
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => DashbordView()),
        );

        await clearForm();


      } else {
        _createError = res.message ?? "Failed to create action point";
      }
    } catch (e) {
      _createError = "Something went wrong: $e";
    } finally {
      _isCreateLoading = false;
      notifyListeners();
    }
  }

  // ================= GENERATE ACTION POINTS =================
  Future<void> generateActionPoints({
    required String meetingNotes,
    required String meetingDate,
    required String projectId,
  }) async {
    if (_selectedMeetingType == null) {
      _aiError = "Please select meeting type";
      notifyListeners();
      return;
    }

    _isAiLoading = true;
    _aiError = null;
    _actionPoints = [];
    notifyListeners();

    try {
      final res = await _aiRepo.generateActionPoints(
        GenerateActionPointAiReqModel(
          meatingNotes: meetingNotes,
          meatingDate: meetingDate,
          projectId: projectId,
          meatingTypeId: _selectedMeetingType!.id.toString(),
        ),
      );

      if (res.success == true && res.actionPoints != null) {
        _actionPoints = res.actionPoints!;
        _actionPointsBatchId++;
      } else {
        _actionPoints = [];
        _aiError = "Failed to generate action points";
      }
    } catch (e) {
      _actionPoints = [];
      _aiError = "Error generating action points: $e";
    } finally {
      _isAiLoading = false;
      notifyListeners();
    }
  }

  // ================= CLEAR FORM =================
  Future<void> clearForm() async {
    dateController.clear();
    notesController.clear();
    ccController.clear();
    projectNameController.clear();
    projectManagerNameController.clear();
    clearAttachments();
    _actionPoints = [];
    _actionPointsBatchId++;
    _selectedEmployeeId = null;
    _createSuccess = null;
    _createError = null;
    _aiError = null;
    notifyListeners();
  }

  // ================= CLEAR ACTION POINTS =================
  void clearActionPoints() {
    _actionPoints = [];
    _actionPointsBatchId++;
    notifyListeners();
  }

  void updateActionPointAssignee(int index, String? employeeId) {
    if (index < 0 || index >= _actionPoints.length) return;
    final p = _actionPoints[index];
    String? name = p.assigneeName;
    if (employeeId != null) {
      name = null;
      for (final e in _employees) {
        if (e.id == employeeId) {
          name = e.employeeName;
          break;
        }
      }
    } else {
      name = null;
    }
    _actionPoints[index] = ActionPoints(
      description: p.description,
      targetDate: p.targetDate,
      assigneeName: name,
      assignedToId: employeeId,
    );
    notifyListeners();
  }

  void updateActionPointTargetDate(int index, String date) {
    if (index < 0 || index >= _actionPoints.length) return;
    final p = _actionPoints[index];
    _actionPoints[index] = ActionPoints(
      description: p.description,
      targetDate: date,
      assigneeName: p.assigneeName,
      assignedToId: p.assignedToId,
    );
    notifyListeners();
  }

  // ================= SELECT EMPLOYEE =================
  void setSelectedEmployee(Data emp) {
    _selectedEmployeeId = emp.id;
    notifyListeners();
  }

  // ================= GET SELECTED EMPLOYEE ID =================
  String? getSelectedEmployeeId() => _selectedEmployeeId;

  // ================= DISPOSE =================
  @override
  void dispose() {
    dateController.dispose();
    notesController.dispose();
    ccController.dispose();
    projectNameController.dispose();
    projectManagerNameController.dispose();
    super.dispose();
  }
}