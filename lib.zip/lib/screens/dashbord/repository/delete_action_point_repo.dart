// repositories/delete_action_point_repository.dart

import 'dart:convert';
import 'package:http/http.dart' as http;
import '../../../service/api_client.dart';
import '../model/delete_action_point_model.dart';

class DeleteActionPointRepository {
  final ApiClient _apiClient = ApiClient();
  static const String deleteActionPointEndpoint = '/api/Pms_api/delete_action_point';
  Future<DeleteActionPointResModel> deleteActionPointByMeetingId(String meetingId) async {
    try {
      final requestBody = DeleteActionPointReqModel(
        meetingId: meetingId,
      );

      final response = await _apiClient.post(
        deleteActionPointEndpoint,
        body: jsonEncode(requestBody.toJson()),
        requiresAuth: true,
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> responseData = jsonDecode(response.body);
        return DeleteActionPointResModel.fromJson(responseData);
      } else {
        return DeleteActionPointResModel(
          success: false,
          message: 'Failed to delete action point. Status code: ${response.statusCode}',
        );
      }
    } catch (e) {
      return DeleteActionPointResModel(
        success: false,
        message: 'Error deleting action point: ${e.toString()}',
      );
    }
  }
  Future<DeleteActionPointResModel> deleteActionPointById(String actionPointId) async {
    try {
      final requestBody = {
        "action_point_id": actionPointId,
      };

      final response = await _apiClient.post(
        deleteActionPointEndpoint,
        body: jsonEncode(requestBody),
        requiresAuth: true,
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> responseData = jsonDecode(response.body);
        return DeleteActionPointResModel.fromJson(responseData);
      } else {
        return DeleteActionPointResModel(
          success: false,
          message: 'Failed to delete action point. Status code: ${response.statusCode}',
        );
      }
    } catch (e) {
      return DeleteActionPointResModel(
        success: false,
        message: 'Error deleting action point: ${e.toString()}',
      );
    }
  }
  Future<DeleteActionPointResModel> deleteActionPoint({
    String? meetingId,
    String? actionPointId,
  }) async {
    try {
      final Map<String, dynamic> requestBody = {};

      if (meetingId != null) {
        requestBody['meeting_id'] = meetingId;
      }
      if (actionPointId != null) {
        requestBody['action_point_id'] = actionPointId;
      }

      if (requestBody.isEmpty) {
        return DeleteActionPointResModel(
          success: false,
          message: 'Either meeting_id or action_point_id is required',
        );
      }

      final response = await _apiClient.post(
        deleteActionPointEndpoint,
        body: jsonEncode(requestBody),
        requiresAuth: true,
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> responseData = jsonDecode(response.body);
        return DeleteActionPointResModel.fromJson(responseData);
      } else {
        return DeleteActionPointResModel(
          success: false,
          message: 'Failed to delete action point. Status code: ${response.statusCode}',
        );
      }
    } catch (e) {
      return DeleteActionPointResModel(
        success: false,
        message: 'Error deleting action point: ${e.toString()}',
      );
    }
  }
}