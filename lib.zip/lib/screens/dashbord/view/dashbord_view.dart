import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../get_action_point_view_screen/view/get_action_view_view.dart';
import '../../get_action_point_view_screen/view/update_action_view.dart';
import '../../get_action_point_view_screen/view_model/get_action_view_view_model.dart';
import '../../login_screen/model/login_model.dart';
import '../../login_screen/view_model/login_screen_view_model.dart';
import '../../meating_action_point_screen/view/meating_action_point_view.dart';
import '../view_model/dashbord_view_model.dart';

class DashbordView extends StatefulWidget {
  String? meetingTypeId;
  DashbordView({super.key, this.meetingTypeId});

  @override
  State<DashbordView> createState() => _DashbordViewState();
}

class _DashbordViewState extends State<DashbordView> {
  String? meetingTypeId;
  int? selectedRowIndex;
  final RefreshIndicatorKey = GlobalKey<RefreshIndicatorState>();

  @override
  void initState() {
    super.initState();
    meetingTypeId = widget.meetingTypeId;
    _loadData();
  }

  Future<void> _loadData() async {
    final vm = context.read<DashbordViewModel>();
    await Future.wait([
      vm.fetchSummary(meetingTypeId: meetingTypeId ?? ""),
      vm.fetchActionPoints(meetingTypeId: meetingTypeId ?? ""),
    ]);
  }

  Future<void> _onRefresh() async {
    await _loadData();
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<LoginProvider>();
    final watch = context.watch<DashbordViewModel>();
    final read = context.read<DashbordViewModel>();

    final canCreateActionPoints = user.hasCreatePermission();
    final canViewActionPoints = user.hasViewPermission();
    final canEditActionPoints = user.hasUpdatePermission();
    final canDeleteActionPoint = user.hasDeletePermission();

    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      body: RefreshIndicator(
        key: RefreshIndicatorKey,
        onRefresh: _onRefresh,
        color: Colors.blue.shade700,
        backgroundColor: Colors.white,
        strokeWidth: 2,
        displacement: 20,
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          slivers: [
            SliverToBoxAdapter(
              child: Column(
                children: [
                  SizedBox(height: 20.h),
                  Padding(
                    padding: EdgeInsets.all(16.w),
                    child: Column(
                      children: [
                        SizedBox(height: 20.h),
                        Row(
                          children: [
                            _buildHeader(),
                            const Spacer(),
                            if (canCreateActionPoints)
                              GestureDetector(
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => const MeetingActionPointView(),
                                    ),
                                  );
                                },
                                child: Container(
                                  height: 40.w,
                                  width: 120,
                                  decoration: BoxDecoration(
                                    color: Colors.blue[700],
                                    borderRadius: BorderRadius.circular(10.r),
                                  ),
                                  child: Row(
                                    children: [
                                      Padding(
                                        padding: EdgeInsets.only(left: 8.w),
                                        child: Icon(Icons.add, size: 18.sp, color: Colors.white),
                                      ),
                                      SizedBox(width: 5.w),
                                      Padding(
                                        padding: EdgeInsets.only(right: 3.w),
                                        child: Text(
                                          "Action Point",
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.w600,
                                            fontSize: 12.sp,
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                              )
                          ],
                        ),
                        SizedBox(height: 10.h),
                        Row(
                          children: [
                            Text("Action Points Summary"),
                          ],
                        ),
                        GridView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            crossAxisSpacing: 12.w,
                            mainAxisSpacing: 12.h,
                            childAspectRatio: 1.5,
                          ),
                          itemCount: 4,
                          itemBuilder: (context, index) {
                            final vm = context.watch<DashbordViewModel>();
                            final summary = vm.summary;
                            final cards = [
                              {
                                'title': 'Total Points',
                                'value': (summary?.total ?? 0).toString(),
                                'icon': Icons.task_alt,
                                'color': Colors.blue
                              },
                              {
                                'title': 'Pending',
                                'value': (summary?.pending ?? 0).toString(),
                                'icon': Icons.pending_actions,
                                'color': Colors.orange
                              },
                              {
                                'title': 'In Progress',
                                'value': (summary?.inprogress ?? 0).toString(),
                                'icon': Icons.play_circle_outline,
                                'color': Colors.purple
                              },
                              {
                                'title': 'Completed',
                                'value': (summary?.completed ?? 0).toString(),
                                'icon': Icons.check_circle_outline,
                                'color': Colors.green
                              },
                            ];
                            return _buildModernCard(
                              cards[index]['title'] as String,
                              cards[index]['value'] as String,
                              cards[index]['icon'] as IconData,
                              cards[index]['color'] as MaterialColor,
                            );
                          },
                        ),
                        SizedBox(height: 24.h),
                        Row(
                          children: [
                            Container(
                              width: 4.w,
                              height: 24.h,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [Colors.blue.shade400, Colors.blue.shade700],
                                ),
                                borderRadius: BorderRadius.circular(2.r),
                              ),
                            ),
                            SizedBox(width: 8.w),
                            Text(
                              "Meeting Action Points",
                              style: TextStyle(
                                fontSize: 20.sp,
                                fontWeight: FontWeight.bold,
                                color: Colors.grey.shade800,
                              ),
                            ),
                            const Spacer(),
                            Container(
                              padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 6.h),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [Colors.blue.shade50, Colors.blue.shade100],
                                ),
                                borderRadius: BorderRadius.circular(20.r),
                              ),
                              child: Row(
                                children: [
                                  Icon(Icons.list_alt, size: 14.sp, color: Colors.blue.shade700),
                                  SizedBox(width: 4.w),
                                  Text(
                                    '${context.watch<DashbordViewModel>().actionPoints.length} Records',
                                    style: TextStyle(
                                      fontSize: 12.sp,
                                      color: Colors.blue.shade700,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 16.h),
                      ],
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.symmetric(horizontal: 16.w),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20.r),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.shade200,
                          blurRadius: 10.r,
                          offset: Offset(0, 5.h),
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(20.r),
                      child: context.watch<DashbordViewModel>().actionPoints.isEmpty
                          ? Container(
                        height: 400.h,
                        child: Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.inbox,
                                size: 80.w,
                                color: Colors.grey.shade400,
                              ),
                              SizedBox(height: 16.h),
                              Text(
                                'No Data Found',
                                style: TextStyle(
                                  fontSize: 18.sp,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.grey.shade600,
                                ),
                              ),
                              SizedBox(height: 8.h),
                              Text(
                                'Pull down to refresh or add new action points',
                                style: TextStyle(
                                  fontSize: 14.sp,
                                  color: Colors.grey.shade500,
                                ),
                              ),
                              SizedBox(height: 16.h),
                              ElevatedButton.icon(
                                onPressed: () => _onRefresh(),
                                icon: Icon(Icons.refresh),
                                label: Text('Refresh'),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.blue.shade700,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.r),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      )
                          : SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Theme(
                          data: Theme.of(context).copyWith(
                            dividerColor: Colors.grey.shade400,
                          ),
                          child: DataTable(
                            columnSpacing: 0,
                            horizontalMargin: 0,
                            headingRowHeight: 56.h,
                            dataRowHeight: 56.h,
                            showCheckboxColumn: false,
                            headingRowColor: MaterialStateProperty.resolveWith(
                                  (states) => Colors.grey.shade100,
                            ),
                            columns: [
                              _buildDataColumnWithBorder('ID', Icons.tag),
                              _buildDataColumnWithBorder('Department', Icons.business),
                              _buildDataColumnWithBorder('Project', Icons.folder),
                              _buildDataColumnWithBorder('Meeting Date', Icons.calendar_today),
                              _buildDataColumnWithBorder('Created By', Icons.person),
                              _buildDataColumnWithBorder('Created Date', Icons.date_range),
                              _buildDataColumnWithBorder('Total', Icons.summarize),
                              _buildDataColumnWithBorder('Pending', Icons.pending),
                              _buildDataColumnWithBorder('Progress', Icons.play_circle),
                              _buildDataColumnWithBorder('Completed', Icons.done_all),
                              _buildDataColumnWithBorder('Status', Icons.flag),
                              const DataColumn(
                                label: Text('Actions'),
                              ),
                            ],
                            rows: context.watch<DashbordViewModel>().actionPoints
                                .asMap()
                                .entries
                                .map((entry) {
                              int index = entry.key;
                              final point = entry.value;

                              Map<String, dynamic> actionPointData = {
                                'id': point.id ?? "",
                                'meeting_id': point.id ?? "",
                                'department': point.meetingTypeName ?? "",
                                'project': point.projectName ?? "",
                                'meetingDate': point.meetingDate ?? "",
                                'createdBy': point.createdByName ?? "",
                                'createdDate': point.createdOn ?? "",
                                'total': point.totalPoints ?? "0",
                                'pending': point.pendingPoints ?? "0",
                                'progress': point.inprogressPoints ?? "0",
                                'completed': point.completedPoints ?? "0",
                                'status': point.overallStatus ?? "",
                              };

                              return DataRow(
                                selected: selectedRowIndex == index,
                                color: MaterialStateProperty.resolveWith(
                                      (states) {
                                    if (selectedRowIndex == index) {
                                      return Colors.blue.shade50;
                                    }
                                    return index.isEven ? Colors.grey.shade50 : Colors.white;
                                  },
                                ),
                                cells: [
                                  DataCell(
                                    Container(
                                      width: 120.w,
                                      padding: EdgeInsets.symmetric(vertical: 8.h, horizontal: 12.w),
                                      child: Text(
                                        point.id ?? "",
                                        style: TextStyle(
                                          fontWeight: FontWeight.w600,
                                          color: Colors.blue.shade700,
                                        ),
                                      ),
                                    ),
                                  ),
                                  DataCell(
                                    Container(
                                      width: 120.w,
                                      padding: EdgeInsets.symmetric(vertical: 8.h, horizontal: 12.w),
                                      child: Text(point.meetingTypeName ?? ""),
                                    ),
                                  ),
                                  DataCell(
                                    Container(
                                      width: 120.w,
                                      padding: EdgeInsets.symmetric(vertical: 8.h, horizontal: 12.w),
                                      child: Text(point.projectName ?? ""),
                                    ),
                                  ),
                                  DataCell(
                                    Container(
                                      width: 120.w,
                                      padding: EdgeInsets.symmetric(vertical: 8.h, horizontal: 12.w),
                                      child: Text(point.meetingDate ?? ""),
                                    ),
                                  ),
                                  DataCell(
                                    Container(
                                      width: 120.w,
                                      padding: EdgeInsets.symmetric(vertical: 8.h, horizontal: 12.w),
                                      child: Text(point.createdByName ?? ""),
                                    ),
                                  ),
                                  DataCell(
                                    Container(
                                      width: 120.w,
                                      padding: EdgeInsets.symmetric(vertical: 8.h, horizontal: 12.w),
                                      child: Text(point.createdOn ?? ""),
                                    ),
                                  ),
                                  DataCell(
                                    Container(
                                      width: 120.w,
                                      padding: EdgeInsets.symmetric(vertical: 8.h, horizontal: 12.w),
                                      child: Text(point.totalPoints ?? "0"),
                                    ),
                                  ),
                                  DataCell(
                                    Container(
                                      width: 120.w,
                                      padding: EdgeInsets.symmetric(vertical: 8.h, horizontal: 12.w),
                                      child: Text(point.pendingPoints ?? "0"),
                                    ),
                                  ),
                                  DataCell(
                                    Container(
                                      width: 120.w,
                                      padding: EdgeInsets.symmetric(vertical: 8.h, horizontal: 12.w),
                                      child: Text(point.inprogressPoints ?? "0"),
                                    ),
                                  ),
                                  DataCell(
                                    Container(
                                      width: 120.w,
                                      padding: EdgeInsets.symmetric(vertical: 8.h, horizontal: 12.w),
                                      child: Text(point.completedPoints ?? "0"),
                                    ),
                                  ),
                                  DataCell(
                                    Container(
                                      width: 120.w,
                                      padding: EdgeInsets.symmetric(vertical: 8.h, horizontal: 12.w),
                                      child: _buildStatusChip(point.overallStatus ?? ""),
                                    ),
                                  ),
                                  DataCell(
                                    Container(
                                      width: 130.w,
                                      padding: EdgeInsets.symmetric(vertical: 8.h, horizontal: 12.w),
                                      child: Row(
                                        children: [
                                          if (canViewActionPoints)
                                            InkWell(
                                              onTap: () {
                                                setState(() {
                                                  selectedRowIndex = index;
                                                });
                                                Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                    builder: (_) => ActionPointViewScreen(
                                                      meetingId: int.tryParse(
                                                        actionPointData['meeting_id']?.toString() ?? '0',
                                                      ) ?? 0,
                                                    ),
                                                  ),
                                                ).then((_) {
                                                  _onRefresh();
                                                });
                                              },
                                              child: Container(
                                                padding: EdgeInsets.all(6.w),
                                                decoration: BoxDecoration(
                                                  color: Colors.blue.shade50,
                                                  borderRadius: BorderRadius.circular(8.r),
                                                ),
                                                child: Icon(
                                                  Icons.visibility,
                                                  size: 18.sp,
                                                  color: Colors.blue.shade700,
                                                ),
                                              ),
                                            ),
                                          if (canViewActionPoints) SizedBox(width: 8.w),
                                          if (canEditActionPoints)
                                            InkWell(
                                              onTap: () async {
                                                setState(() {
                                                  selectedRowIndex = index;
                                                });
                                                final meetingId = int.tryParse(
                                                      actionPointData['meeting_id']
                                                              ?.toString() ??
                                                          '0',
                                                    ) ??
                                                    0;
                                                final vm = context
                                                    .read<GetActionPointViewModel>();
                                                await vm.fetchActionPointView(meetingId);
                                                if (!context.mounted) return;
                                                Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                    builder: (context) =>
                                                        ActionPointFormScreen(
                                                      viewModel: vm,
                                                      meetingId: meetingId,
                                                    ),
                                                  ),
                                                ).then((_) {
                                                  _onRefresh();
                                                });
                                              },
                                              child: Container(
                                                padding: EdgeInsets.all(6.w),
                                                decoration: BoxDecoration(
                                                  color: Colors.orange.shade50,
                                                  borderRadius: BorderRadius.circular(8.r),
                                                ),
                                                child: Icon(
                                                  Icons.edit,
                                                  size: 18.sp,
                                                  color: Colors.orange.shade700,
                                                ),
                                              ),
                                            ),


                                          if (canEditActionPoints) SizedBox(width: 8.w),
                                          if (canDeleteActionPoint)
                                            InkWell(
                                              onTap: () {
                                                setState(() {
                                                  selectedRowIndex = index;
                                                });
                                                _deleteActionPoint(actionPointData, index);
                                              },
                                              child: Container(
                                                padding: EdgeInsets.all(6.w),
                                                decoration: BoxDecoration(
                                                  color: Colors.red.shade50,
                                                  borderRadius: BorderRadius.circular(8.r),
                                                ),
                                                child: Icon(
                                                  Icons.delete,
                                                  size: 18.sp,
                                                  color: Colors.red.shade700,
                                                ),
                                              ),
                                            ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              );
                            }).toList(),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 16.h),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        Container(
          padding: EdgeInsets.all(10.w),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.blue.shade400, Colors.blue.shade700],
            ),
            borderRadius: BorderRadius.circular(12.r),
          ),
          child: Icon(Icons.dashboard, color: Colors.white, size: 24.sp),
        ),
        SizedBox(width: 12.w),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Dashboard",
              style: TextStyle(
                fontSize: 24.sp,
                fontWeight: FontWeight.bold,
                color: Colors.grey.shade800,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildModernCard(String title, String value, IconData icon, MaterialColor color) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [color.shade400, color.shade700],
        ),
        borderRadius: BorderRadius.circular(20.r),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.3),
            blurRadius: 10.r,
            offset: Offset(0, 4.h),
          ),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.all(16.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Container(
                  padding: EdgeInsets.all(8.w),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12.r),
                  ),
                  child: Icon(icon, color: Colors.white, size: 24.sp),
                ),
                SizedBox(width: 6.w),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 32.sp,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
            SizedBox(height: 12.h),
            Text(
              title,
              style: TextStyle(
                fontSize: 11.sp,
                color: Colors.white.withOpacity(0.9),
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  DataColumn _buildDataColumnWithBorder(String label, IconData icon) {
    return DataColumn(
      label: Container(
        width: 120.w,
        padding: EdgeInsets.symmetric(vertical: 8.h, horizontal: 12.w),
        decoration: BoxDecoration(
          border: Border(
            right: BorderSide(color: Colors.grey.shade400, width: 1),
          ),
        ),
        child: Row(
          children: [
            Icon(icon, size: 16.sp, color: Colors.grey.shade600),
            SizedBox(width: 6.w),
            Expanded(
              child: Text(
                label,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 13.sp,
                  color: Colors.grey.shade700,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusChip(String status) {
    Color color;
    IconData icon;

    switch (status.toLowerCase()) {
      case 'pending':
        color = Colors.orange;
        icon = Icons.pending;
        break;
      case 'in progress':
        color = Colors.blue;
        icon = Icons.play_circle_outline;
        break;
      case 'completed':
        color = Colors.green;
        icon = Icons.check_circle_outline;
        break;
      default:
        color = Colors.grey;
        icon = Icons.help_outline;
    }

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 0.w, vertical: 6.h),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color.withOpacity(0.1), color.withOpacity(0.05)],
        ),
        borderRadius: BorderRadius.circular(20.r),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(width: 2.w),
          Icon(icon, size: 14.sp, color: color),
          SizedBox(width: 4.w),
          Text(
            status,
            style: TextStyle(
              fontSize: 12.sp,
              fontWeight: FontWeight.w600,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  void _editActionPoint(Map<String, dynamic> actionPointData, int index) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Edit Action Point"),
          content: Text("Edit functionality for ${actionPointData['id']}"),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("Cancel"),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text("Edit feature coming soon")),
                ).closed.then((_) {
                  _onRefresh();
                });
              },
              child: Text("Save"),
            ),
          ],
        );
      },
    );
  }

  void _deleteActionPoint(Map<String, dynamic> actionPointData, int index) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Delete Action Point"),
          content: Text("Are you sure you want to delete ${actionPointData['id']}?"),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("Cancel"),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              onPressed: () async {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text("Deleting...")),
                );
                await Future.delayed(Duration(seconds: 1));
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text("Delete feature coming soon")),
                ).closed.then((_) {
                  _onRefresh();
                });
              },
              child: Text("Delete"),
            ),
          ],
        );
      },
    );
  }
}