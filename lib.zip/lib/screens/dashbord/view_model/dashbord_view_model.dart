import 'package:flutter/cupertino.dart';
import '../model/action_point_summary_point_model.dart';
import '../model/get_action_point_model.dart';
import '../repository/action_summary_point_repo.dart';
import '../repository/get_action_point_repo.dart';

class DashbordViewModel extends ChangeNotifier {

  final ActionPointSummaryRepository _repository =
  ActionPointSummaryRepository();

  /// ================= STATE =================
  ActionSummary? _summary;
  bool _isLoading = false;
  String? _error;

  /// ================= GETTERS =================
  ActionSummary? get summary => _summary;
  bool get isLoading => _isLoading;
  String? get error => _error;

  /// ================= FETCH SUMMARY =================
  Future<void> fetchSummary({
    required String meetingTypeId,
    String status = "all",
  }) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      final result = await _repository.getSummary(
        ActionPointSummaryPointsReqModel(
          status: status,
          meetingTypeId: meetingTypeId,
        ),
      );

      if (result.success == true && result.actionSummary != null) {
        _summary = result.actionSummary;
      } else {
        _summary = null;
        _error = "Failed to load summary";
      }
    } catch (e) {
      _summary = null;
      _error = "Something went wrong";
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
  final GetActionPointRepository _actionRepo = GetActionPointRepository();

  List<ActionPoint> _actionPoints = [];
  bool _isTableLoading = false;
  String? _tableError;

  List<ActionPoint> get actionPoints => _actionPoints;
  bool get isTableLoading => _isTableLoading;
  String? get tableError => _tableError;

  Future<void> fetchActionPoints({
    required String meetingTypeId,
    String status = "all",
  }) async {
    print("00000000");
    _isTableLoading = true;
    _tableError = null;
    notifyListeners();

    try {
      final res = await _actionRepo.getActionPoints(
        GetActionPointReqModel(
          status: status,
          meetingTypeId: meetingTypeId,
        ),
      );

      if (res.success == true && res.actionPoint != null) {
        _actionPoints = res.actionPoint!;
      } else {
        _actionPoints = [];
        _tableError = "No data found";
      }
    } catch (e) {
      _actionPoints = [];
      _tableError = "Something went wrong";
    } finally {
      _isTableLoading = false;
      notifyListeners();
    }
  }

  Future<void> refreshSummary(String meetingTypeId) async {
    await fetchSummary(meetingTypeId: meetingTypeId);
  }
  void clearSummary() {
    _summary = null;
    notifyListeners();
  }
}